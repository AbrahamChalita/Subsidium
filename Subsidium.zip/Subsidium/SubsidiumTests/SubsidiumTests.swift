//
//  SubsidiumTests.swift
//  SubsidiumTests
//
//  Created by Abraham Chalita on 09/10/22.
//

import XCTest
import Amplify
import AWSPluginsCore


@testable import Subsidium

final class SubsidiumTests: XCTestCase {
    
    var noticias = [New]()

    func testAmplifyAPI() async throws {
        //crear una variable de tipo expectativa para que se detenga hasta un cierto tiempo
        let expectation = XCTestExpectation(description: #function)
//        crear un controlador de los datos
        let newViewController = await Subsidium.NewsViewController()
        
        do{
            let noticias = try await newViewController.fecthDataNewsTest()
            expectation.fulfill() //se completa la expectativa
            updateUI(with: noticias) //se actualiza el valor obtenido hacia la variable de clase
        }catch{
            XCTFail()
        }
            
    
        wait(for: [expectation], timeout: 5.0) //esperar 3 segundos a que la expectativa se completa
        
        XCTAssertEqual(self.noticias.isEmpty, false) // ejemplo de aserción verdadera
        //XCTAssertEqual(self.reservas[0].titulo, "un dato")//ejemplo de aserción falsa
        
    }
    
    func updateUI(with noticias: [New]){
//        se actualiza la variable de clase
            self.noticias = noticias
    }



}
