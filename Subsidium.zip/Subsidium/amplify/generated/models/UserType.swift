// swiftlint:disable all
import Amplify
import Foundation

public enum UserType: String, EnumPersistable {
  case generalAdmin = "GENERAL_ADMIN"
  case admin = "ADMIN"
  case user = "USER"
}