// swiftlint:disable all
import Amplify
import Foundation

public struct Modifications: Model {
  public let id: String
  public var userID: String
  public var type: String
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      userID: String,
      type: String) {
    self.init(id: id,
      userID: userID,
      type: type,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      userID: String,
      type: String,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.userID = userID
      self.type = type
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}