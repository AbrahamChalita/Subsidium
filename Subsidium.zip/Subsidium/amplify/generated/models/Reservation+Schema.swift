// swiftlint:disable all
import Amplify
import Foundation

extension Reservation {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case userID
    case deviceID
    case licenceID
    case roomID
    case reservationDate
    case reservationTime
    case reservationDuration
    case state
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let reservation = Reservation.keys
    
    model.pluralName = "Reservations"
    
    model.fields(
      .id(),
      .field(reservation.userID, is: .required, ofType: .string),
      .field(reservation.deviceID, is: .optional, ofType: .string),
      .field(reservation.licenceID, is: .optional, ofType: .string),
      .field(reservation.roomID, is: .optional, ofType: .string),
      .field(reservation.reservationDate, is: .required, ofType: .string),
      .field(reservation.reservationTime, is: .optional, ofType: .string),
      .field(reservation.reservationDuration, is: .optional, ofType: .int),
      .field(reservation.state, is: .required, ofType: .string),
      .field(reservation.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(reservation.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}