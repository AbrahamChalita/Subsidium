// swiftlint:disable all
import Amplify
import Foundation

public struct User: Model {
  public let id: String
  public var username: String
  public var name: String
  public var surname: String
  public var email: String
  public var type: UserType?
  public var verified: Bool
  public var active: Bool
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      username: String,
      name: String,
      surname: String,
      email: String,
      type: UserType? = nil,
      verified: Bool,
      active: Bool) {
    self.init(id: id,
      username: username,
      name: name,
      surname: surname,
      email: email,
      type: type,
      verified: verified,
      active: active,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      username: String,
      name: String,
      surname: String,
      email: String,
      type: UserType? = nil,
      verified: Bool,
      active: Bool,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.username = username
      self.name = name
      self.surname = surname
      self.email = email
      self.type = type
      self.verified = verified
      self.active = active
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}