// swiftlint:disable all
import Amplify
import Foundation

extension Modifications {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case userID
    case type
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let modifications = Modifications.keys
    
    model.pluralName = "Modifications"
    
    model.fields(
      .id(),
      .field(modifications.userID, is: .required, ofType: .string),
      .field(modifications.type, is: .required, ofType: .string),
      .field(modifications.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(modifications.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}