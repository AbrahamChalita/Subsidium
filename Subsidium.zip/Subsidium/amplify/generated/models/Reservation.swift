// swiftlint:disable all
import Amplify
import Foundation

public struct Reservation: Model {
  public let id: String
  public var userID: String
  public var deviceID: String?
  public var licenceID: String?
  public var roomID: String?
  public var reservationDate: String
  public var reservationTime: String?
  public var reservationDuration: Int?
  public var state: String
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      userID: String,
      deviceID: String? = nil,
      licenceID: String? = nil,
      roomID: String? = nil,
      reservationDate: String,
      reservationTime: String? = nil,
      reservationDuration: Int? = nil,
      state: String) {
    self.init(id: id,
      userID: userID,
      deviceID: deviceID,
      licenceID: licenceID,
      roomID: roomID,
      reservationDate: reservationDate,
      reservationTime: reservationTime,
      reservationDuration: reservationDuration,
      state: state,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      userID: String,
      deviceID: String? = nil,
      licenceID: String? = nil,
      roomID: String? = nil,
      reservationDate: String,
      reservationTime: String? = nil,
      reservationDuration: Int? = nil,
      state: String,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.userID = userID
      self.deviceID = deviceID
      self.licenceID = licenceID
      self.roomID = roomID
      self.reservationDate = reservationDate
      self.reservationTime = reservationTime
      self.reservationDuration = reservationDuration
      self.state = state
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}