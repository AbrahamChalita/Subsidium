// swiftlint:disable all
import Amplify
import Foundation

extension New {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case title
    case description
    case date_published
    case image
    case content
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let new = New.keys
    
    model.pluralName = "News"
    
    model.fields(
      .id(),
      .field(new.title, is: .required, ofType: .string),
      .field(new.description, is: .required, ofType: .string),
      .field(new.date_published, is: .required, ofType: .string),
      .field(new.image, is: .required, ofType: .string),
      .field(new.content, is: .required, ofType: .string),
      .field(new.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(new.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}