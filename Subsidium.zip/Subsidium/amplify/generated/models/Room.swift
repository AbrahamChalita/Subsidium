// swiftlint:disable all
import Amplify
import Foundation

public struct Room: Model {
  public let id: String
  public var name: String
  public var building: String
  public var floor: String?
  public var proyector: Bool
  public var wifi: Bool
  public var board: Bool
  public var air_conditioner: Bool
  public var ethernet: Bool
  public var computers: Bool
  public var double_monitor: Bool
  public var seats: Int
  public var energy_outlets: Int
  public var description: String
  public var images: [String?]
  public var active: Bool?
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      name: String,
      building: String,
      floor: String? = nil,
      proyector: Bool,
      wifi: Bool,
      board: Bool,
      air_conditioner: Bool,
      ethernet: Bool,
      computers: Bool,
      double_monitor: Bool,
      seats: Int,
      energy_outlets: Int,
      description: String,
      images: [String?] = [],
      active: Bool? = nil) {
    self.init(id: id,
      name: name,
      building: building,
      floor: floor,
      proyector: proyector,
      wifi: wifi,
      board: board,
      air_conditioner: air_conditioner,
      ethernet: ethernet,
      computers: computers,
      double_monitor: double_monitor,
      seats: seats,
      energy_outlets: energy_outlets,
      description: description,
      images: images,
      active: active,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      name: String,
      building: String,
      floor: String? = nil,
      proyector: Bool,
      wifi: Bool,
      board: Bool,
      air_conditioner: Bool,
      ethernet: Bool,
      computers: Bool,
      double_monitor: Bool,
      seats: Int,
      energy_outlets: Int,
      description: String,
      images: [String?] = [],
      active: Bool? = nil,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.name = name
      self.building = building
      self.floor = floor
      self.proyector = proyector
      self.wifi = wifi
      self.board = board
      self.air_conditioner = air_conditioner
      self.ethernet = ethernet
      self.computers = computers
      self.double_monitor = double_monitor
      self.seats = seats
      self.energy_outlets = energy_outlets
      self.description = description
      self.images = images
      self.active = active
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}