// swiftlint:disable all
import Amplify
import Foundation

extension Room {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case name
    case building
    case floor
    case proyector
    case wifi
    case board
    case air_conditioner
    case ethernet
    case computers
    case double_monitor
    case seats
    case energy_outlets
    case description
    case images
    case active
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let room = Room.keys
    
    model.pluralName = "Rooms"
    
    model.fields(
      .id(),
      .field(room.name, is: .required, ofType: .string),
      .field(room.building, is: .required, ofType: .string),
      .field(room.floor, is: .optional, ofType: .string),
      .field(room.proyector, is: .required, ofType: .bool),
      .field(room.wifi, is: .required, ofType: .bool),
      .field(room.board, is: .required, ofType: .bool),
      .field(room.air_conditioner, is: .required, ofType: .bool),
      .field(room.ethernet, is: .required, ofType: .bool),
      .field(room.computers, is: .required, ofType: .bool),
      .field(room.double_monitor, is: .required, ofType: .bool),
      .field(room.seats, is: .required, ofType: .int),
      .field(room.energy_outlets, is: .required, ofType: .int),
      .field(room.description, is: .required, ofType: .string),
      .field(room.images, is: .required, ofType: .embeddedCollection(of: String.self)),
      .field(room.active, is: .optional, ofType: .bool),
      .field(room.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(room.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}