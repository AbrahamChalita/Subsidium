// swiftlint:disable all
import Amplify
import Foundation

extension UnavailableDates {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case deviceID
    case licenceID
    case roomID
    case dates
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let unavailableDates = UnavailableDates.keys
    
    model.pluralName = "UnavailableDates"
    
    model.fields(
      .id(),
      .field(unavailableDates.deviceID, is: .optional, ofType: .string),
      .field(unavailableDates.licenceID, is: .optional, ofType: .string),
      .field(unavailableDates.roomID, is: .optional, ofType: .string),
      .field(unavailableDates.dates, is: .optional, ofType: .embeddedCollection(of: String.self)),
      .field(unavailableDates.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(unavailableDates.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}