// swiftlint:disable all
import Amplify
import Foundation

extension Licence {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case name
    case year
    case compatibility
    case category
    case description
    case images
    case active
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let licence = Licence.keys
    
    model.pluralName = "Licences"
    
    model.fields(
      .id(),
      .field(licence.name, is: .required, ofType: .string),
      .field(licence.year, is: .required, ofType: .int),
      .field(licence.compatibility, is: .required, ofType: .embeddedCollection(of: String.self)),
      .field(licence.category, is: .required, ofType: .embeddedCollection(of: String.self)),
      .field(licence.description, is: .required, ofType: .string),
      .field(licence.images, is: .required, ofType: .embeddedCollection(of: String.self)),
      .field(licence.active, is: .optional, ofType: .bool),
      .field(licence.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(licence.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}