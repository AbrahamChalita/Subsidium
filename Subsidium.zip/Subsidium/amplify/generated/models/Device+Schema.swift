// swiftlint:disable all
import Amplify
import Foundation

extension Device {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case name
    case portable
    case os
    case processor
    case storage
    case ram
    case description
    case images
    case active
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let device = Device.keys
    
    model.pluralName = "Devices"
    
    model.fields(
      .id(),
      .field(device.name, is: .required, ofType: .string),
      .field(device.portable, is: .required, ofType: .bool),
      .field(device.os, is: .required, ofType: .string),
      .field(device.processor, is: .optional, ofType: .string),
      .field(device.storage, is: .required, ofType: .int),
      .field(device.ram, is: .required, ofType: .int),
      .field(device.description, is: .required, ofType: .string),
      .field(device.images, is: .required, ofType: .embeddedCollection(of: String.self)),
      .field(device.active, is: .optional, ofType: .bool),
      .field(device.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(device.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}