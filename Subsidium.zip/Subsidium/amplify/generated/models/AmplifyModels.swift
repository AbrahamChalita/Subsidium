// swiftlint:disable all
import Amplify
import Foundation

// Contains the set of classes that conforms to the `Model` protocol. 

final public class AmplifyModels: AmplifyModelRegistration {
  public let version: String = "5fa89978e2c08da05bd95c0bf6028853"
  
  public func registerModels(registry: ModelRegistry.Type) {
    ModelRegistry.register(modelType: Note.self)
    ModelRegistry.register(modelType: Device.self)
    ModelRegistry.register(modelType: Licence.self)
    ModelRegistry.register(modelType: Room.self)
    ModelRegistry.register(modelType: User.self)
    ModelRegistry.register(modelType: Reservation.self)
    ModelRegistry.register(modelType: Modifications.self)
    ModelRegistry.register(modelType: UnavailableDates.self)
    ModelRegistry.register(modelType: New.self)
  }
}