// swiftlint:disable all
import Amplify
import Foundation

public struct Device: Model {
  public let id: String
  public var name: String
  public var portable: Bool
  public var os: String
  public var processor: String?
  public var storage: Int
  public var ram: Int
  public var description: String
  public var images: [String?]
  public var active: Bool?
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      name: String,
      portable: Bool,
      os: String,
      processor: String? = nil,
      storage: Int,
      ram: Int,
      description: String,
      images: [String?] = [],
      active: Bool? = nil) {
    self.init(id: id,
      name: name,
      portable: portable,
      os: os,
      processor: processor,
      storage: storage,
      ram: ram,
      description: description,
      images: images,
      active: active,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      name: String,
      portable: Bool,
      os: String,
      processor: String? = nil,
      storage: Int,
      ram: Int,
      description: String,
      images: [String?] = [],
      active: Bool? = nil,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.name = name
      self.portable = portable
      self.os = os
      self.processor = processor
      self.storage = storage
      self.ram = ram
      self.description = description
      self.images = images
      self.active = active
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}