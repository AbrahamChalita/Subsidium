// swiftlint:disable all
import Amplify
import Foundation

public struct New: Model {
  public let id: String
  public var title: String
  public var description: String
  public var date_published: String
  public var image: String
  public var content: String
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      title: String,
      description: String,
      date_published: String,
      image: String,
      content: String) {
    self.init(id: id,
      title: title,
      description: description,
      date_published: date_published,
      image: image,
      content: content,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      title: String,
      description: String,
      date_published: String,
      image: String,
      content: String,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.title = title
      self.description = description
      self.date_published = date_published
      self.image = image
      self.content = content
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}