// swiftlint:disable all
import Amplify
import Foundation

public struct Licence: Model {
  public let id: String
  public var name: String
  public var year: Int
  public var compatibility: [String?]
  public var category: [String?]
  public var description: String
  public var images: [String?]
  public var active: Bool?
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      name: String,
      year: Int,
      compatibility: [String?] = [],
      category: [String?] = [],
      description: String,
      images: [String?] = [],
      active: Bool? = nil) {
    self.init(id: id,
      name: name,
      year: year,
      compatibility: compatibility,
      category: category,
      description: description,
      images: images,
      active: active,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      name: String,
      year: Int,
      compatibility: [String?] = [],
      category: [String?] = [],
      description: String,
      images: [String?] = [],
      active: Bool? = nil,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.name = name
      self.year = year
      self.compatibility = compatibility
      self.category = category
      self.description = description
      self.images = images
      self.active = active
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}