// swiftlint:disable all
import Amplify
import Foundation

extension User {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case username
    case name
    case surname
    case email
    case type
    case verified
    case active
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let user = User.keys
    
    model.pluralName = "Users"
    
    model.fields(
      .id(),
      .field(user.username, is: .required, ofType: .string),
      .field(user.name, is: .required, ofType: .string),
      .field(user.surname, is: .required, ofType: .string),
      .field(user.email, is: .required, ofType: .string),
      .field(user.type, is: .optional, ofType: .enum(type: UserType.self)),
      .field(user.verified, is: .required, ofType: .bool),
      .field(user.active, is: .required, ofType: .bool),
      .field(user.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(user.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}