// swiftlint:disable all
import Amplify
import Foundation

public struct UnavailableDates: Model {
  public let id: String
  public var deviceID: String?
  public var licenceID: String?
  public var roomID: String?
  public var dates: [String?]?
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      deviceID: String? = nil,
      licenceID: String? = nil,
      roomID: String? = nil,
      dates: [String?]? = nil) {
    self.init(id: id,
      deviceID: deviceID,
      licenceID: licenceID,
      roomID: roomID,
      dates: dates,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      deviceID: String? = nil,
      licenceID: String? = nil,
      roomID: String? = nil,
      dates: [String?]? = nil,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.deviceID = deviceID
      self.licenceID = licenceID
      self.roomID = roomID
      self.dates = dates
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}