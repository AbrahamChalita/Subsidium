//
//  ImageDownloader.swift
//  Subsidium
//
//  Created by Abraham Chalita on 12/10/22.
//

import Foundation
import Amplify
import AWSPluginsCore

func getImageURL(noticia: New) -> URL{
    var link = URL(string: "google.com")
    let semaphore = DispatchSemaphore(value: 0)
    
    Amplify.Storage.getURL(key: noticia.image) { event in
        switch event {
        case let .success(url):
            print("Completed, retrieved url correctly")
            link = url
            semaphore.signal()
        case let .failure(storageError):
            print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
        }
    }
    
    semaphore.wait()
    
    return link!
}
