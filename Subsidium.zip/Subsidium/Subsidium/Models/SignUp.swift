//
//  SignUp.swift
//  Subsidium
//
//  Created by Abraham Chalita on 07/10/22.
//

import Foundation
import UIKit
import Amplify
import AWSPluginsCore
import Combine

struct SignUp{
    var signUpSuccessful: Bool
    var confirmedSuccessful: Bool
    var addedToDataBase: Bool
    var isActive: Bool
    var resetConfirmation: Bool?
    var isThereResetError: Bool?
    var resetError: AuthError?
}

extension SignUp{
    static func signIn(username: String, password: String) {
        Amplify.Auth.signIn(username: username, password: password) { result in
            switch result {
            case .success:
                print("Sign in succeeded")
            case .failure(let error):
                print("Sign in failed \(error)")
            }
        }
    }
    
    static func signOutLocally() {
        Amplify.Auth.signOut() { result in
            switch result {
            case .success:
                print("Successfully signed out")
            case .failure(let error):
                print("Sign out failed with error \(error)")
            }
        }
    }
    
    static func signOutGlobally(){
        Amplify.Auth.signOut(options: .init(globalSignOut: true)) { result in
                switch result {
                case .success:
                    print("Successfully signed out")
                case .failure(let error):
                    print("Sign out failed with error \(error)")
                }
            }
    }
    
    static func invalidNameOfUser(_ value: String) -> String?{
        let regex = "^([a-zA-Z]{2,}\\s[a-zA-Z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)"
        
        let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
        
        if !predicate.evaluate(with: value){
            return "Invalid Name"
        }
        
        return nil
    }
    
    static func invalidEmail(_ value: String) -> String?{
        let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
        
        if !predicate.evaluate(with: value){
            return "Invalid email address"
        }
        
        return nil
    }
    
    static func invalidPassword(_ value: String) -> String?{
        let regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&#])[A-Za-z\\d$@$!%*?&#]{12,}"
        
        let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
        
        if !predicate.evaluate(with: value){
            return "Invalid (12 ch. 1 sp. 1 num. 1 MAY)"
        }
        
        return nil
    }
    
    static func invalidUsername(_ value: String) -> String?{
        let regex = "^[A-Za-z][A-Za-z0-9_]{4,29}"
        
        let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
        
        if !predicate.evaluate(with: value){
            return "Username"
        }
        
        return nil
    }
    
}
