//
//  reserva.swift
//  Subsidium
//
//  Created by Abraham Chalita on 30/09/22.
//

import Foundation
import UIKit

struct reserva{
    
    /*
    var titulo: String
    var status: String
    var descripcion1: String
    var descripcion2: String
    var imagenReserva: UIImage!
    var fecha: Date
     */
    
}

/*
extension reserva{
    static func reservationsArray() -> [reserva]{
        var tempReservas: [reserva] = []
        
        let reserva1 = reserva(titulo: "Salon Prueba - 000 A", status: "Pendiente", descripcion1: "Lunes, Agosto 25", descripcion2: "12:00 pm", imagenReserva: UIImage(named: "espacio2"), fecha: Date.now)
        
        tempReservas.append(reserva1)
        
        return tempReservas
    }
}
*/
