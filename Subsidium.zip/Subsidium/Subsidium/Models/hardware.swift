//
//  hardware.swift
//  Subsidium
//
//  Created by Abraham Chalita on 02/10/22.
//

import Foundation
import UIKit

struct hardware{
    var nombre: String
    var ram: String
    var memoria: String
    var procesador: String
    var imagenHardware: UIImage!
    var disponibilidad: String
}


extension hardware{
    static func createArray() -> [hardware]{
        var tempHardware: [hardware] = []
        
        let hardware1 = hardware(nombre: "Macbook pro 16'", ram: "32 GB", memoria: "512 GB", procesador: "M1 MAX", imagenHardware: UIImage(named: "macbook"), disponibilidad: "3u")
        
        tempHardware.append(hardware1)
        
        return tempHardware
    }
    
    
    
}
