//
//  UsersInfo.swift
//  Subsidium
//
//  Created by ARANZA RIVAS NUÑO on 30/09/22.
//

import Foundation

struct UsersInfo {
    
    var Img: String
    
    var Name: String
    var Email: String
    var TypeP: String
    var NumA: String
    
}

extension UsersInfo
{
    
    static func UsersInfoList() -> [UsersInfo]
    {
        return ( [ UsersInfo(Img: "ProfilePicU", Name: "James Sunderland", Email: "silentHills@gmail.com", TypeP: "Estandar", NumA: "0") ,
                   UsersInfo(Img: "ProfilePicU2", Name: "Goro Majima", Email: "yazu4@itesm.mx", TypeP: "Estandar", NumA: "5")] )
    }

}
        
        
        /*,
        ProfileInfo(Img: "ProfilePicU2", Name: "Goro Majima", Email: "yazu4@itesm.mx", Age: "24", Status: true, TypeP: "Estandar")*/
