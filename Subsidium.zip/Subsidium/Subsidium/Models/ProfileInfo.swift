//
//  ProfileInfo.swift
//  Subsidium
//
//  Created by Jesus Rivas on 29/09/22.
//

import Foundation

struct ProfileInfo {
    
    var Img: String
    
    var Name: String
    var Email: String
    var Age: String
    var Status: Bool
    var TypeP: String
    
}

extension ProfileInfo
{
    
    static func InfoList() -> [ProfileInfo]
    {
        return ( [ProfileInfo(Img: "ProfilePicU", Name: "James Sunderland", Email: "silentHills@gmail.com", Age: "29", Status: true, TypeP: "Estandar"),
                  ProfileInfo(Img: "ProfilePicU2", Name: "Goro Majima", Email: "yazu4@itesm.mx", Age: "24", Status: true, TypeP: "Estandar"),
                  ProfileInfo(Img: "ProfilePicA", Name: "John Boss", Email: "bigBoss@tec.mx", Age: "49", Status: true, TypeP: "Administrador")] )
        
        
        /*,
        ProfileInfo(Img: "ProfilePicU2", Name: "Goro Majima", Email: "yazu4@itesm.mx", Age: "24", Status: true, TypeP: "Estandar")*/
    }
}
