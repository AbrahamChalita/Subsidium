//
//  espacio.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//
import Foundation
import UIKit

struct espacio{
    var nombre: String
    var piso: String
    var capacidad: String
    var disponibilidad: UIImage!
    var imagen: UIImage!
    var imagenCaracteristicas: UIImage!
}


extension espacio{
    static func createArray() -> [espacio]{
        var tempEspacios: [espacio] = []
        
        let espacio1 = espacio(nombre: "Salón QCDT - 207 A", piso: "Piso 2", capacidad: "22", disponibilidad: UIImage(named: "green"), imagen: UIImage(named: "espacio2"), imagenCaracteristicas: UIImage(named: "caracteristics1"))
        
        let espacio2 = espacio(nombre: "Salón QCDT - 107 B", piso: "Piso 1", capacidad: "10", disponibilidad: UIImage(named: "yellow"), imagen: UIImage(named: "espacio"), imagenCaracteristicas: UIImage(named: "caracteristics1"))
        
        tempEspacios.append(espacio1)
        tempEspacios.append(espacio2)
        
        return tempEspacios
    }
}
