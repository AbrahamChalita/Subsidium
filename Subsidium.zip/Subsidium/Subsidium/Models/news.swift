//
//  news.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import Foundation
import UIKit

struct news{
    var url: URL?
}
