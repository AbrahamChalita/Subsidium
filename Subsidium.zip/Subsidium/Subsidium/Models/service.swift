//
//  service.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import Foundation
import UIKit

struct service{
    var title: String
    var featuredImage: UIImage?
    var color: UIColor
}

extension service{
    static func createArray() -> [service]{
        var tempService: [service] = []
        
        let service2 = service(title: "Hardware", featuredImage: UIImage(named: "hardware"), color: UIColor(red: 63/255.0, green: 71/255.0, blue: 80/255.0, alpha: 0.8))
        
        let service1 = service(title: "Espacios", featuredImage: UIImage(named: "espacio"), color: UIColor(red: 240/255.0, green: 133/255.0, blue: 91/255.0, alpha: 0.8))
        
        let service3 = service(title: "Software", featuredImage: UIImage(named: "software"), color: UIColor(red: 105/255.0, green: 80/255.0, blue: 227/255.0, alpha: 0.8))
        

        
        tempService.append(service1)
        tempService.append(service2)
        tempService.append(service3)
        
        return tempService
    }
}
