//
//  History.swift
//  Subsidium
//
//  Created by Jesús Rivas on 28/09/22.
//

import Foundation

struct History{
    
    var title: String
    var estatus: String
    
    var DiaSemP: String
    var MesP: String
    var DiaMesP: String
    
    var DiaSemE: String
    var MesE: String
    var DiaMesE: String
    
    var img: String
}

extension History
{
    static func historyList() -> [History]
    {
        return ( [History(title: "Matlab (2020)", estatus: "Enviado", DiaSemP: "Jueves", MesP: "Agosto", DiaMesP: "13", DiaSemE: "16:00 - ", MesE: "17:00", DiaMesE: "PM", img: "MatlabHist"),
                 History(title: "Salón QCDT - 309", estatus: "Completado", DiaSemP: "Viernes", MesP: "Agosto", DiaMesP: "14", DiaSemE: "Sabado", MesE: "Noviembre", DiaMesE: "12", img: "SCompuHist") ] )
    }
}
