//
//  ViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

