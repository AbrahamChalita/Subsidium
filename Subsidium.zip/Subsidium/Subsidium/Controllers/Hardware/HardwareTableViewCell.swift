//
//  HardwareTableViewCell.swift
//  Subsidium
//
//  Created by Abraham Chalita on 02/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class HardwareTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var hardwareTitle: UILabel!
    @IBOutlet weak var hardwareRam: UILabel!
    @IBOutlet weak var hardwareMemory: UILabel!
    @IBOutlet weak var hardwareCPU: UILabel!
    @IBOutlet weak var hardwareDisponibilidad: UILabel!
    @IBOutlet weak var hardwareImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func getImageURL(device: Device) -> URL{
        var link = URL(string: "google.com")
        let semaphore = DispatchSemaphore(value: 0)
        
        Amplify.Storage.getURL(key: device.images[0]!) { event in
            switch event {
            case let .success(url):
                print("Completed, retrieved url correctly")
                link = url
                semaphore.signal()
            case let .failure(storageError):
                print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
            }
        }
        
        semaphore.wait()
        
        return link!
    }
    
    func setHardware(hardware: Device){
        hardwareTitle.text = hardware.name
        hardwareRam.text = String(hardware.ram)
        hardwareMemory.text = String(hardware.storage)
        hardwareCPU.text = hardware.processor
        hardwareDisponibilidad.text = hardware.os
        
        let urlString = getImageURL(device: hardware)
        hardwareImage.downloaded(from: urlString)
    }

}
