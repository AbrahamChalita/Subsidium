//
//  CalendarTestViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 15/10/22.
//

import UIKit
import FSCalendar
import Amplify
import AWSPluginsCore
import Combine

struct ResDur{
    var date: String
    var duration: Int
};

class CalendarTestViewController: UIViewController, FSCalendarDelegate, FSCalendarDataSource, FSCalendarDelegateAppearance {
    
    var duraciones = ["5 días", "10 días", "15 días", "20 días", "25 días", "30 días"]
    var duraciones1 = ["5 días"]
    var duraciones2 = ["5 días", "10 días", "15 días", "20 días", "25 días", "30 días"]
    
    var changedDuration: [String] = []
    var d = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"]
    var duraTest: [Int] = []
    
    var disabledDates: [String] = []
    let defaults = UserDefaults.standard
    var diasSelect: Int = 0
    var selected: String = ""
    var ayuda: Int = 0
    
    var currentDevice: Device = Device(name: "", portable: true, os: "", processor: "", storage: 0, ram: 0, description: "", active: false)
    
    @IBOutlet var pupUp: UIView!
    @IBOutlet weak var duracionReservaText: UITextField!
    
    let pickerHoras = UIPickerView()
    @IBOutlet weak var calendario: FSCalendar!
    var formatter = DateFormatter()
    
    var datesFromQuery: [ResDur] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pupUp.layer.cornerRadius = 6
        pupUp.layer.masksToBounds = true
        
        calendario.register(FSCalendarCell.self, forCellReuseIdentifier: "CELL")
        calendario.scrollDirection = .horizontal
        calendario.appearance.todayColor = .systemGreen
        
        calendario.dataSource = self
        calendario.delegate = self
        
        datesFromQuery = getHardwareOccupiedDates()
        
        for i in datesFromQuery{
            disabledDates.append(i.date)
            formatter.dateFormat = "yyyy-MM-dd"
            var new = Calendar.current.date(byAdding: .day, value: 1, to: formatter.date(from: i.date)!)
            let formatted = formatter.string(from: new!)
            print(formatted)
            disabledDates.append(formatted)
            for _ in 1...i.duration-2{
                new = Calendar.current.date(byAdding: .day, value: 1, to: new!)
                let formatted = formatter.string(from: new!)
                print(formatted)
                disabledDates.append(formatted)
            }
        }
        
    }
    
    
    @IBAction func makeHardwareReservation(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "confirmHardwareViewController") as? confirmHardwareViewController
        vc?.modalPresentationStyle = .popover
        self.present(vc!, animated: true)
        print("Date selected - > \(selected) with duration -----> \(String(describing: duracionReservaText.text))")
        
        let date = Date()
        let dateFormateado = DateFormatter()
        dateFormateado.dateFormat = "HH:mm"
        let formatted = dateFormateado.string(from: date)
        
        let reservaDevice = Reservation(userID: defaults.string(forKey: "CurrentUserId")!, deviceID: currentDevice.id, reservationDate: selected, reservationTime: formatted, reservationDuration: Int(duracionReservaText.text!), state: "Sin recoger")
        
        createReservationDB(reservationToCreate: reservaDevice)
    }
    
    func createReservationDB(reservationToCreate: Reservation){
        Amplify.API.mutate(request: .create(reservationToCreate)) { event in
            switch event {
            case .success(let result):
                switch result{
                case .success(let res):
                    print("Successfully added reservation (Device) to database: \(res)")
                case .failure(let error):
                    print("Got failed result with: \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
        
    }
    
    func getHardwareOccupiedDates() -> ([ResDur]){
        
        var values: [ResDur] = []
        let semaphore = DispatchSemaphore(value: 0)
        let todo = Reservation.keys
        let predicate = todo.deviceID == currentDevice.id
        let request = GraphQLRequest<Reservation>.list(Reservation.self, where: predicate)
        Amplify.API.query(request: request) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todos):
                        print("Successfully retrieved list of todos: \(todos)")
                        for i in todos{
                            let val = ResDur(date: i.reservationDate, duration: i.reservationDuration ?? 0)
                            values.append(val)
                        }
                        semaphore.signal()
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        return values
    }
    

}

extension CalendarTestViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return duraciones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return duraciones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.duracionReservaText.text = self.duraciones[row]
        diasSelect = row
    }
    
 
    func createToolBarPicker() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPicker))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    
    func createPicker(input: String){
        
        formatter.dateFormat = "yyyy-MM-dd"
        var counter: Int = 0
        var added = Calendar.current.date(byAdding: .day, value: 1, to: formatter.date(from: input)!)
        let addedFormated = formatter.string(from: added!)
        if disabledDates.contains(addedFormated){
            self.duraciones = ["0"]
        }else{
            for _ in 1...90{
                added = Calendar.current.date(byAdding: .day, value: 1, to: added!)
                if disabledDates.contains(formatter.string(from: added!)){
                    break
                }else{
                    counter += 1
                }
            }
            
            if counter > 13{
                counter = 14
            }
            
            self.duraciones = Array(d[0...counter])
        }
        
        pickerHoras.delegate = self
        pickerHoras.dataSource = self
        
        duracionReservaText.inputView = pickerHoras
        duracionReservaText.inputAccessoryView = createToolBarPicker()
        
        
    }
    
    
    @objc func donePressedPicker(){
        let row = self.pickerHoras.selectedRow(inComponent: 0)
        self.pickerHoras.selectRow(row, inComponent: 0, animated: false)
        self.duracionReservaText.text = self.duraciones[row]
        
        self.view.endEditing(true)
      
    }
    
    func minimumDate(for calendar: FSCalendar) -> Date {
        return Date()
    }
    
    func maximumDate(for calendar: FSCalendar) -> Date {
        return Calendar.current.date(byAdding: .month, value: 3, to: Date())!
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        formatter.dateFormat = "yyyy-MM-dd"
        self.selected = formatter.string(from: date)
        createPicker(input: formatter.string(from: date))
    }
    
    func calendar(_ calendar: FSCalendar, cellFor date: Date, at position: FSCalendarMonthPosition) -> FSCalendarCell {
        let cell: FSCalendarCell = calendar.dequeueReusableCell(withIdentifier: "CELL", for: date, at: position)
        let dateFromStringFormatter = DateFormatter()
        dateFromStringFormatter.dateFormat = "yyyy-MM-dd"
        let calendarDate = dateFromStringFormatter.string(from: date)
        
        if disabledDates.contains(calendarDate) {
            cell.isUserInteractionEnabled = false
        }else{
            cell.isUserInteractionEnabled = true
        }
        
        return cell
    }
        
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleDefaultColorFor date: Date) -> UIColor? {
        formatter.dateFormat = "yyyy-MM-dd"
        
        for i in disabledDates{
            guard let excluded = formatter.date(from: i) else { return nil }
            if date.compare(excluded) == .orderedSame {
                return .red
            }
        }
        
        return nil
    }
    
    
    
    
}
