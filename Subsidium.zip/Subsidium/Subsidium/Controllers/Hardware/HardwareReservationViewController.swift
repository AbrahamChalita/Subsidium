//
//  HardwareReservationViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 02/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine

class HardwareReservationViewController: UIViewController {
    
    let duraciones = ["5 días", "10 días", "15 días", "20 días", "25 días", "30 días"]
    let defaults = UserDefaults.standard
    var diasSelect: Int = 0
    
    var currentDevice: Device = Device(name: "", portable: true, os: "", processor: "", storage: 0, ram: 0, description: "", active: false)
    
    @IBOutlet weak var popView: UIView!
    
    let pickerView = UIPickerView()
    let datePickerFecha = UIDatePicker()
    
    @IBOutlet weak var textDuracion: UITextField!
    @IBOutlet weak var textFecha: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        popView.layer.cornerRadius = 6
        popView.layer.masksToBounds = true
        
        createDatePicker()
        createPicker()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func reserveButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "confirmHardwareViewController") as? confirmHardwareViewController
        vc?.modalPresentationStyle = .popover
        self.present(vc!, animated: true)
        
        var duracionSelect: Int = 0
        
        if diasSelect == 0 {
            duracionSelect = 5
        }else if diasSelect == 1{
            duracionSelect = 10
        }else if diasSelect == 2{
            duracionSelect = 15
        }else if diasSelect == 3{
            duracionSelect = 20
        }else if diasSelect == 4{
            duracionSelect = 25
        }else if diasSelect == 5{
            duracionSelect = 30
        }
        
        let reservaDevice = Reservation(userID: defaults.string(forKey: "CurrentUserId")!, deviceID: currentDevice.id, reservationDate: textFecha.text!, reservationTime: textFecha.text!, reservationDuration: duracionSelect, state: "Sin recoger")
        
        createReservationDB(reservationToCreate: reservaDevice)
    }
    
    func createReservationDB(reservationToCreate: Reservation){
        Amplify.API.mutate(request: .create(reservationToCreate)) { event in
            switch event {
            case .success(let result):
                switch result{
                case .success(let res):
                    print("Successfully added reservation (Device) to database: \(res)")
                case .failure(let error):
                    print("Got failed result with: \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
        
    }
    
    
}


extension HardwareReservationViewController: UIPickerViewDelegate, UIPickerViewDataSource{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return duraciones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return duraciones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.textDuracion.text = self.duraciones[row]
        diasSelect = row
    }
    
    
    func createToolBar() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createToolBarPicker() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPicker))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createDatePicker(){
        datePickerFecha.preferredDatePickerStyle = .inline
        datePickerFecha.datePickerMode = .date
        datePickerFecha.minimumDate = Date()
        textFecha.inputView = datePickerFecha
        
        textFecha.inputAccessoryView = createToolBar()
    }
    
    func createPicker(){
        pickerView.delegate = self
        pickerView.dataSource = self
        
        textDuracion.inputView = pickerView
        textDuracion.inputAccessoryView = createToolBarPicker()
    }
    
    @objc func donePressed(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM d"
        
        self.textFecha.text = dateFormatter.string(from: datePickerFecha.date)
        
        self.view.endEditing(true)
    }
    
    @objc func donePressedPicker(){
        let row = self.pickerView.selectedRow(inComponent: 0)
        self.pickerView.selectRow(row, inComponent: 0, animated: false)
        self.textDuracion.text = self.duraciones[row]
        
        self.view.endEditing(true)
    }
    
}
