//
//  confirmHardwareViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 03/10/22.
//

import UIKit
import Lottie

class confirmHardwareViewController: UIViewController {
    
    @IBOutlet weak var confirmedView: UIView!
    @IBOutlet weak var cancelButton: UIView!
    @IBOutlet weak var animationView: AnimationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpAnimation()
        
        confirmedView.layer.cornerRadius = 6
        confirmedView.layer.masksToBounds = true
        
        cancelButton.layer.cornerRadius = 6
        cancelButton.layer.borderWidth = 1
        cancelButton.layer.borderColor = UIColor.gray.cgColor
    }
    
    @IBAction func cancelAction(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func okAction(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func setUpAnimation(){
        let subAnimationView = AnimationView(name: "okHard")
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .playOnce
        animationView.animationSpeed = 1.0
        animationView.addSubview(subAnimationView)
        subAnimationView.frame = animationView.bounds
        subAnimationView.play()
    }
}
