//
//  StaticServicesViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 09/10/22.
//

import UIKit

class StaticServicesViewController: UIViewController {
    
    
    @IBOutlet weak var popSign: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    @IBAction func goToLoginSignUp(_ sender: UIButton) {
        tabBarController?.selectedIndex = 3
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
