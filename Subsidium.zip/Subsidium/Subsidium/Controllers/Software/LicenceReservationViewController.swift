//
//  LicenceReservationViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 08/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine

class LicenceReservationViewController: UIViewController{
    
    let duraciones = ["5 días", "10 días", "15 días", "20 días", "25 días", "30 días"]
    let defaults = UserDefaults.standard
    var diasSelect: Int = 0
    
    var currentLicence: Licence = Licence(name: "", year: 0, description: "", active: false)
    
    @IBOutlet weak var popUpView: UIView!
    @IBOutlet weak var duracionReservaText: UITextField!
    @IBOutlet weak var inicioReservaText: UITextField!
    
    let pickerView = UIPickerView()
    let datePickerFecha = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        popUpView.layer.cornerRadius = 6
        popUpView.layer.masksToBounds = true
        
        createDatePicker()
        createPicker()
    }
    
    
    @IBAction func solicitarButton(_ sender: UIButton) {
        var duracionSelect: Int = 0
        
        if diasSelect == 0 {
            duracionSelect = 5
        }else if diasSelect == 1{
            duracionSelect = 10
        }else if diasSelect == 2{
            duracionSelect = 15
        }else if diasSelect == 3{
            duracionSelect = 20
        }else if diasSelect == 4{
            duracionSelect = 25
        }else if diasSelect == 5{
            duracionSelect = 30
        }
        
        let date = Date()
        let dateFormateado = DateFormatter()
        dateFormateado.dateFormat = "HH:mm"
        let formatted = dateFormateado.string(from: date)
        
        
        let reservaDevice = Reservation(userID: defaults.string(forKey: "CurrentUserId")!, licenceID: currentLicence.id, reservationDate: inicioReservaText.text!, reservationTime: formatted, reservationDuration: duracionSelect, state: "Enviado")
        
        createReservationDB(reservationToCreate: reservaDevice)
        dismiss(animated: true)
    }
    
    func createReservationDB(reservationToCreate: Reservation){
        Amplify.API.mutate(request: .create(reservationToCreate)) { event in
            switch event {
            case .success(let result):
                switch result{
                case .success(let res):
                    print("Successfully added reservation (Device) to database: \(res)")
                case .failure(let error):
                    print("Got failed result with: \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
        
    }
    

}

extension LicenceReservationViewController: UIPickerViewDelegate, UIPickerViewDataSource{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return duraciones.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return duraciones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.duracionReservaText.text = self.duraciones[row]
    }
    
    
    func createToolBar() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createToolBarPicker() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPicker))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createDatePicker(){
        datePickerFecha.preferredDatePickerStyle = .inline
        datePickerFecha.datePickerMode = .date
        datePickerFecha.minimumDate = Date()
        datePickerFecha.maximumDate = Calendar.current.date(byAdding: .month, value: 3, to: Date())!
        inicioReservaText.inputView = datePickerFecha
        
        inicioReservaText.inputAccessoryView = createToolBar()
    }
    
    func createPicker(){
        pickerView.delegate = self
        pickerView.dataSource = self
        
        duracionReservaText.inputView = pickerView
        duracionReservaText.inputAccessoryView = createToolBarPicker()
    }
    
    @objc func donePressed(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        self.inicioReservaText.text = dateFormatter.string(from: datePickerFecha.date)
        
        self.view.endEditing(true)
    }
    
    @objc func donePressedPicker(){
        let row = self.pickerView.selectedRow(inComponent: 0)
        self.pickerView.selectRow(row, inComponent: 0, animated: false)
        self.duracionReservaText.text = self.duraciones[row]
        
        self.view.endEditing(true)
    }
    
    
}
