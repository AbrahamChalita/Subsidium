//
//  LicenciasViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 08/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class LicenciasViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var TableView: UITableView!
    var licencias: [Licence] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        TableView.delegate = self
        TableView.dataSource = self
        
        fetchLicencias()
        // Do any additional setup after loading the view.
    }
    
    
    func fetchLicencias(){
        let software = Licence.keys
        let predicate = software.active == true
        let request = GraphQLRequest<Licence>.list(Licence.self, where: predicate)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let lista):
                    print("Successfully retrieved list of Licences: \(lista)")
                    self.licencias = lista
                    self.updateUI(with: lista)
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    
    func updateUI(with licencias: [Licence]){
        DispatchQueue.main.async {
            self.licencias = self.licencias
            self.TableView.reloadData()
        }
    }
    



}

extension LicenciasViewController{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return licencias.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let licencia = licencias[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "licenciaCell") as! LicenciaTableViewCell
        
        cell.setLicencia(licencia: licencia)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LicenceReservationViewController") as? LicenceReservationViewController
        vc?.currentLicence = licencias[indexPath.row]
        
        vc?.modalPresentationStyle = .popover
        self.present(vc!, animated: true)
    }
    
    
}
