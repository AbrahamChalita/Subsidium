//
//  LicenciaTableViewCell.swift
//  Subsidium
//
//  Created by Abraham Chalita on 08/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class LicenciaTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var licenceTitle: UILabel!
    @IBOutlet weak var licenceDescription: UILabel!
    @IBOutlet weak var licencePlatforms: UILabel!
    @IBOutlet weak var licenceImage: UIImageView!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func getImageURL(licencia: Licence) -> URL{
        var link = URL(string: "google.com")
        let semaphore = DispatchSemaphore(value: 0)
        
        Amplify.Storage.getURL(key: licencia.images[0]!) { event in
            switch event {
            case let .success(url):
                print("Completed, retrieved url correctly")
                link = url
                semaphore.signal()
            case let .failure(storageError):
                print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
            }
        }
        
        semaphore.wait()
        
        return link!
    }
    
    
    func setLicencia(licencia: Licence){
        let title: String = licencia.name + " " + String(licencia.year)
        licenceTitle.text = title
        licenceDescription.text = licencia.description
        licencePlatforms.text = "MacOS, Windows, Linux"
        
        let urlString = getImageURL(licencia: licencia)
        licenceImage.downloaded(from: urlString)
    }

}
