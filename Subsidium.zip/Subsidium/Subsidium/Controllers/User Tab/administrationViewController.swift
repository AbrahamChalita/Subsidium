//
//  administrationViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 14/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine

class administrationViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var users: [User] = []
    let defaults = UserDefaults.standard
    @IBOutlet weak var adminTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        adminTableView.delegate = self
        adminTableView.dataSource = self

        listUsers()
    }
        
    
    func listUsers() {
        let user = User.keys
        let predicate = user.username != defaults.string(forKey: "CurrentUser") && user.type != "GENERAL_ADMIN"
        let request = GraphQLRequest<User>.list(User.self, where: predicate)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let todos):
                    print("Successfully retrieved list of users: \(todos)")
                    self.users = todos
                    self.updateUIUsers(with: todos)
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    func updateUIUsers(with usuarios: [User]){
        DispatchQueue.main.async {
            self.users = self.users
            self.adminTableView.reloadData()
        }
    }
    
    func setUserActive(usuario: User){
        var user = usuario
        user.active = true
        Amplify.API.mutate(request: .update(user)) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let user):
                    print("Successfully set user \(user) status to: ACTIVE")
                case.failure(let error):
                    print("Got failed result \(error.errorDescription)")
                }
            case.failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    func deactivateUser(usuario: User){
        var user = usuario
        user.active = false
        Amplify.API.mutate(request: .update(user)) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let user):
                    print("Successfully set user \(user) status to: UNACTIVE")
                case.failure(let error):
                    print("Got failed result \(error.errorDescription)")
                }
            case.failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    

}

extension administrationViewController: adminUserTableViewCellDelegate{
    func didTapButton(with usuario: User, state: Bool) {
        if state == false{
            deactivateUser(usuario: usuario)
        }else if (state == true){
            setUserActive(usuario: usuario)
        }
    }
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let usuario = users[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "userAdminCell") as! adminUserTableViewCell
        
        cell.delegate = self
        cell.setUsuario(usuario: usuario)
        
        return cell
    }
    
}
