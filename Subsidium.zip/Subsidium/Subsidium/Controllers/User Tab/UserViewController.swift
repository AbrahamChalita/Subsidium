//
//  UserViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 08/10/22.
//

import UIKit

class UserViewController: UIViewController {
    
    let defaults = UserDefaults.standard
    let date = Date()
    
    @IBOutlet weak var nameOfUser: UILabel!
    @IBOutlet weak var todaysDate: UILabel!
    @IBOutlet weak var userMail: UILabel!
    @IBOutlet weak var userActive: UILabel!
    @IBOutlet weak var userType: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameOfUser.text = defaults.string(forKey: "CurrentUserName")! + " " + defaults.string(forKey: "CurrentUserLastName")!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE, d MMMM"
        todaysDate.text = dateFormatter.string(from: date)
        
        userMail.text = defaults.string(forKey: "CurrentUserMail")
        userActive.text = "Active"
        userType.text = defaults.string(forKey: "CurrentUserType")!
    }
    

    

}
