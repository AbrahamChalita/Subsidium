//
//  confirmedPassChangeViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 16/10/22.
//

import UIKit
import Lottie

class confirmedPassChangeViewController: UIViewController {
    
    
    @IBOutlet weak var confirmedChange: UIView!
    @IBOutlet weak var animationView: AnimationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpAnimation()

        confirmedChange.layer.cornerRadius = 8
        confirmedChange.layer.masksToBounds = true
        
    }
    
    
    @IBAction func dismissButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func setUpAnimation(){
        let subAnimationView = AnimationView(name: "okHard")
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .playOnce
        animationView.animationSpeed = 1.0
        animationView.addSubview(subAnimationView)
        subAnimationView.frame = animationView.bounds
        subAnimationView.play()
    }

}
