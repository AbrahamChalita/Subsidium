//
//  adminUserTableViewCell.swift
//  Subsidium
//
//  Created by Abraham Chalita on 14/10/22.
//

import UIKit

protocol adminUserTableViewCellDelegate: AnyObject {
    func didTapButton(with usuario: User, state: Bool)
}

class adminUserTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var nameOfuser: UILabel!
    @IBOutlet weak var userMail: UILabel!
    @IBOutlet weak var userType: UILabel!
    @IBOutlet weak var userActiveSwitch: UISwitch!
    
    private var currentUser: User = User(username: "", name: "", surname: "", email: "", verified: false, active: false)
    
    weak var delegate: adminUserTableViewCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    @IBAction func didTapButton(){
        delegate?.didTapButton(with: currentUser, state: userActiveSwitch.isOn)
    }
    
    func setUsuario(usuario: User){
        self.currentUser = usuario
        
        nameOfuser.text = usuario.name + " " + usuario.surname
        userMail.text = usuario.email
        userType.text = usuario.type?.rawValue
        
        if usuario.active == true{
            userActiveSwitch.setOn(true, animated: true)
        }else{
            userActiveSwitch.setOn(false, animated: true)
        }
    }
    
    
}
