//
//  PasswordChangeViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 16/10/22.
//

import UIKit
import Amplify
import AWSAPIPlugin

class PasswordChangeViewController: UIViewController {
    
    let defaults = UserDefaults.standard
    
    @IBOutlet weak var oldPassword: UITextField!
    @IBOutlet weak var newPassword: UITextField!
    @IBOutlet weak var confirmNewPassword: UITextField!
    
    
    @IBOutlet weak var oldPError: UILabel!
    @IBOutlet weak var newPError1: UILabel!
    @IBOutlet weak var newPError2: UILabel!
    
    @IBOutlet weak var confirmButton: UIButton!
    @IBOutlet var TapScreen: UITapGestureRecognizer!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        resetForm()
    }
    
    @IBAction func screenTapped(_ sender: UITapGestureRecognizer) {
        oldPassword.resignFirstResponder()
        newPassword.resignFirstResponder()
        confirmNewPassword.resignFirstResponder()
    }
    
    
    @IBAction func changePassword(_ sender: Any) {
        
        showAlert(title: "Confirmación", message: "La contraseña ha sido actualizada")
        changePassword(oldPassword: oldPassword.text!, newPassword: newPassword.text!)
    }
    
    func changePassword(oldPassword: String, newPassword: String) {
        Amplify.Auth.update(oldPassword: oldPassword, to: newPassword) { result in
            switch result {
            case .success:
                print("Change password succeeded")
            case .failure(let error):
                print("Change password failed with error \(error)")
            }
        }
    }
    
    func resetForm(){
        confirmButton.isEnabled = false
        
        oldPError.isHidden = false
        newPError1.isHidden = false
        newPError2.isHidden = false
        
        oldPError.text = "*"
        newPError2.text = "*"
        newPError1.text = "*"
        
        oldPassword.text = ""
        newPassword.text = ""
        confirmNewPassword.text = ""
        
    }
    
    
    @IBAction func oldChanged(_ sender: Any) {
        if let oldpass = oldPassword.text {
            if let errorMessage = invalidOldPassword(oldpass){
                oldPError.text = errorMessage
                oldPError.isHidden = false
            }else{
                oldPError.isHidden = true
            }
        }
        
        checkForm()
    }
    
    func invalidOldPassword(_ value: String) -> String? {
        if value != defaults.string(forKey: "SecretPassword"){
            return "Clave actual incorrecta"
        }
        
        return nil
    }
    
    func checkForm(){
        if oldPError.isHidden && newPError1.isHidden && newPError2.isHidden{
            confirmButton.isEnabled = true
        }else{
            confirmButton.isEnabled = false
        }
    }
    
    
    @IBAction func newOneChanged(_ sender: Any) {
        if let newOne = newPassword.text {
            if let errorMessage = SignUp.invalidPassword(newOne){
                newPError1.text = errorMessage
                newPError1.isHidden = false
            }else{
                newPError1.isHidden = true
            }
        }
        
        checkForm()
    }
    
    
    @IBAction func newTwoChanged(_ sender: Any) {
        if let confirmed = confirmNewPassword.text{
            if let errorMessage = invalidConfirmed(confirmed){
                newPError2.text = errorMessage
                newPError2.isHidden = false
            }else{
                newPError2.isHidden = true
            }
        }
        
        checkForm()
    }
    
    func invalidConfirmed(_ value: String) -> String? {
        
        if value != newPassword.text{
            return "Nueva clave no coincide"
        }
        
        return nil
    }
    
    func showAlert(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {action in print("Dismiss")}))
        self.present(alert, animated:true, completion: nil)
    }
   
}
