//
//  HistoryTableViewCell.swift
//  Subsidium
//
//  Created by Abraham Chalita on 08/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class HistoryTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var reservationTitle: UILabel!
    @IBOutlet weak var reservationStatus: UILabel!
    @IBOutlet weak var reservationDesc1: UILabel!
    @IBOutlet weak var reservationDesc2: UILabel!
    @IBOutlet weak var reservationImage: UIImageView!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func getImageURL(llave: String) -> URL{
        var link = URL(string: "google.com")
        let semaphore = DispatchSemaphore(value: 0)
        
        Amplify.Storage.getURL(key: llave) { event in
            switch event {
            case let .success(url):
                print("Completed, retrieved url correctly")
                link = url
                semaphore.signal()
            case let .failure(storageError):
                print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
            }
        }
        
        semaphore.wait()
        
        return link!
    }
    
    func getLicenceImageKey(reservation: Reservation) -> String{
        var link = ""
        let semaphore = DispatchSemaphore(value: 0)

        Amplify.API.query(request: .get(Licence.self, byId: reservation.licenceID!)) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todo):
                        guard let todo = todo else {
                            print("Could not find todo")
                            return
                        }
                        print("Successfully retrieved Licence Image Key: \(String(describing: todo.images[0]))")
                        link = todo.images[0]!
                        semaphore.signal()
                        
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        
        return link
    }
    
    func getLicenceName(reservation: Reservation) -> String{
        var link = ""
        let semaphore = DispatchSemaphore(value: 0)

        Amplify.API.query(request: .get(Licence.self, byId: reservation.licenceID!)) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todo):
                        guard let todo = todo else {
                            print("Could not find todo")
                            return
                        }
                        print("Successfully retrieved Licence name: \(todo.name)")
                        link = todo.name
                        semaphore.signal()
                        
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        
        return link
    }
    
    func sethistory(reservation: Reservation){
        if reservation.roomID == nil && reservation.deviceID == nil {
            
            let name = getLicenceName(reservation: reservation)
            
            reservationTitle.text = name
            reservationStatus.text = reservation.state
            reservationDesc1.text = reservation.reservationDate
            
            let duration: String = String(reservation.reservationDuration ?? 1)
            reservationDesc2.text = duration + " días"
            
            let urlString = getImageURL(llave: getLicenceImageKey(reservation: reservation))
            reservationImage.downloaded(from: urlString)
        }
    }

}
