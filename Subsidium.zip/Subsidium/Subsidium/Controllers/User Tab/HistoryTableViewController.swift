//
//  HistoryTableViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 03/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class HistoryTableViewController: UITableViewController {

    var userHist: [Reservation] = []
    let defaults = UserDefaults.standard

    override func viewDidLoad() {
        super.viewDidLoad()
        
        listHistory()
        
    }
    
    func listHistory() {
        let historial = Reservation.keys
        let predicate = historial.userID == defaults.string(forKey: "CurrentUserId") && historial.deviceID == nil && historial.roomID == nil
    
        let request = GraphQLRequest<Reservation>.list(Reservation.self, where: predicate)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let historial):
                    print("Successfully retrieved list of Historial: \(historial)")
                    self.userHist = historial
                    self.updateUIHistory(with: historial)
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    func updateUIHistory(with reservaciones: [Reservation]){
        DispatchQueue.main.async {
            self.userHist = self.userHist
            self.tableView.reloadData()
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return userHist.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let reservation = userHist[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryCell", for: indexPath) as! HistoryTableViewCell

        cell.sethistory(reservation: reservation)
        return cell
    }
    
    @objc func refresh(sender:AnyObject){
        // Se actualiza la info
        listHistory()
        self.refreshControl?.endRefreshing()
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
