//
//  DeleteUserViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 09/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine

class DeleteUserViewController: UIViewController {
    
    let defaults = UserDefaults.standard

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func deleteUser(_ sender: Any) {
        var currentUser = User(id: defaults.string(forKey: "CurrentUserId")!,username: defaults.string(forKey: "CurrentUser")!, name: defaults.string(forKey: "CurrentUserName")!, surname: defaults.string(forKey: "CurrentUserName")!, email: defaults.string(forKey: "CurrentUserMail")!, verified: true, active: defaults.bool(forKey: "CurrentUserActive"))
        
        deleteUser()
        deleteUserPortal(UserToDelete: currentUser)
        
        let myTabBar = self.storyboard?.instantiateViewController(withIdentifier: "NotSignInTabBar") as! UITabBarController
        myTabBar.modalPresentationStyle = .fullScreen
        self.present(myTabBar, animated: true)
    }
    
    func deleteUser() {
        Amplify.Auth.deleteUser() { result in
            switch result {
            case .success:
                print("Successfully deleted user")
            case .failure(let error):
                print("Delete user failed with error \(error)")
            }
        }
    }
    
    func deleteUserPortal(UserToDelete: User){
        Amplify.API.mutate(request: .delete(UserToDelete)) { event in
            switch event {
            case .success(let result):
                switch result{
                case .success(let reservation):
                    print("Successfully updated reservation in database: \(reservation)")
                case .failure(let error):
                    print("Got failed result with: \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }

    

}
