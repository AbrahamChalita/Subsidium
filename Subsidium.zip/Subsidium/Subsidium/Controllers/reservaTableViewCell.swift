//
//  reservaTableViewCell.swift
//  Subsidium
//
//  Created by Abraham Chalita on 30/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class reservaTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var imagenReserva: UIImageView!
    @IBOutlet weak var tituloReserva: UILabel!
    @IBOutlet weak var estatusReserva: UILabel!
    @IBOutlet weak var reservaDesc1: UILabel!
    @IBOutlet weak var reservaDesc2: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func getRoomName(reservation: Reservation) -> String{
        var link = ""
        let semaphore = DispatchSemaphore(value: 0)

        Amplify.API.query(request: .get(Room.self, byId: reservation.roomID!)) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todo):
                        guard let todo = todo else {
                            print("Could not find todo")
                            return
                        }
                        print("Successfully retrieved Room name: \(todo.name)")
                        link = todo.building + " " + todo.name
                        semaphore.signal()
                        
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        
        return link
    }
    
    func getDeviceName(reservation: Reservation) -> String{
        var link = ""
        let semaphore = DispatchSemaphore(value: 0)

        Amplify.API.query(request: .get(Device.self, byId: reservation.deviceID!)) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todo):
                        guard let todo = todo else {
                            print("Could not find todo")
                            return
                        }
                        print("Successfully retrieved Device name: \(todo.name)")
                        link = todo.name
                        semaphore.signal()
                        
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        
        return link
    }
    
    func getImageRoomKey(reservation: Reservation) -> String{
        var link = ""
        let semaphore = DispatchSemaphore(value: 0)

        Amplify.API.query(request: .get(Room.self, byId: reservation.roomID!)) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todo):
                        guard let todo = todo else {
                            print("Could not find todo")
                            return
                        }
                        print("Successfully retrieved Licence Image Key: \(String(describing: todo.images[0]))")
                        link = todo.images[0]!
                        semaphore.signal()
                        
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        
        return link
    }
    
    
    func getImageDeviceKey(reservation: Reservation) -> String{
        var link = ""
        let semaphore = DispatchSemaphore(value: 0)

        Amplify.API.query(request: .get(Device.self, byId: reservation.deviceID!)) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todo):
                        guard let todo = todo else {
                            print("Could not find todo")
                            return
                        }
                        print("Successfully retrieved Licence Image Key: \(String(describing: todo.images[0]))")
                        link = todo.images[0]!
                        semaphore.signal()
                        
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        
        return link
    }
    
    func getImageURL(llave: String) -> URL{
        var link = URL(string: "google.com")
        let semaphore = DispatchSemaphore(value: 0)
        
        Amplify.Storage.getURL(key: llave) { event in
            switch event {
            case let .success(url):
                print("Completed, retrieved url correctly")
                link = url
                semaphore.signal()
            case let .failure(storageError):
                print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
            }
        }
        
        semaphore.wait()
        
        return link!
    }
    
    
    func updateReserva(r: Reservation){
        if r.roomID != nil{
            
            let urlString = getImageURL(llave: getImageRoomKey(reservation: r))
            imagenReserva.downloaded(from: urlString)
            
            let roomName = getRoomName(reservation: r)
            tituloReserva.text = roomName
            estatusReserva.text = r.state
            reservaDesc1.text = r.reservationDate
            reservaDesc2.text = r.reservationTime! + ", " + r.reservationDuration!.description + " min"
        }else if r.deviceID != nil {
            
            let urlString = getImageURL(llave: getImageDeviceKey(reservation: r))
            imagenReserva.downloaded(from: urlString)
            
            let deviceName = getDeviceName(reservation: r)
            tituloReserva.text = deviceName
            estatusReserva.text = r.state
            reservaDesc1.text = r.reservationDate + ", " + String(r.reservationDuration!) + " días"
            reservaDesc2.text = "Recoger: CEDETEC 202"
        }
    }

}
