//
//  misReservasViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 30/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine

class misReservasViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var reservas: [Reservation] = []
    let defaults = UserDefaults.standard
    @IBOutlet weak var reservaTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        reservaTableView.delegate = self
        reservaTableView.dataSource = self
        
        
        listReservations()
        
        
    }
    
    func listReservations() {
        let todo = Reservation.keys
        let predicate = todo.userID == defaults.string(forKey: "CurrentUserId") && (todo.roomID != nil || todo.deviceID != nil)
    
        let request = GraphQLRequest<Reservation>.list(Reservation.self, where: predicate)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let todos):
                    print("Successfully retrieved list of reservations: \(todos)")
                    self.reservas = todos
                    self.updateUIReservations(with: todos)
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    func updateUIReservations(with reservaciones: [Reservation]){
        DispatchQueue.main.async {
            self.reservas = self.reservas
            self.reservaTableView.reloadData()
        }
    }
    
    
    
    @IBAction func refreshInfo(_ sender: Any) {
       listReservations()
    }
    
    
    
    @IBSegueAction func prepararSiguiente(_ coder: NSCoder, sender: Any?) -> AddEditReservaTableViewController? {
        if let cell = sender as? UITableViewCell, let indexPath = reservaTableView.indexPath(for: cell) {
            // Editing Emoji
            let reservaToEdit = reservas[indexPath.row]
            return AddEditReservaTableViewController(coder: coder, r: reservaToEdit)
            
        } else {
            // Adding Emoji
            return AddEditReservaTableViewController(coder: coder, r: nil)
        }
    }
    
        

}

extension misReservasViewController{
    
    func numberOfSections(in reservaTableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reservas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reservationCell", for: indexPath) as! reservaTableViewCell
        
        let indice = indexPath.row
        let reserva = reservas[indice]
        cell.updateReserva(r: reserva)
        cell.showsReorderControl = true
        return cell
    }
    
    
    @IBAction func editButtonTapped(_ sender: UIBarButtonItem){
        let tableViewEditingMode = reservaTableView.isEditing
        reservaTableView.setEditing(!tableViewEditingMode, animated: true)
    }
    
    func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
        let movedReserva = reservas.remove(at: fromIndexPath.row)
        reservas.insert(movedReserva, at: to.row)
    }
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            let resToDelete = Reservation(id: reservas[indexPath.row].id, userID: defaults.string(forKey: "CurrentUserId")!, deviceID: reservas[indexPath.row].deviceID, licenceID: reservas[indexPath.row].licenceID, roomID: reservas[indexPath.row].roomID, reservationDate: reservas[indexPath.row].reservationDate, reservationTime: reservas[indexPath.row].reservationTime, reservationDuration: reservas[indexPath.row].reservationDuration, state: reservas[indexPath.row].state)
            
            deleteReservationDB(resToDelete: resToDelete)
            
            reservas.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
                
            
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    
    
    func deleteReservationDB(resToDelete: Reservation){
        Amplify.API.mutate(request: .delete(resToDelete)) { event in
            switch event {
            case .success(let result):
                switch result{
                case .success(let reservation):
                    print("Successfully deleted reservation in database: \(reservation)")
                case .failure(let error):
                    print("Got failed result with: \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    @IBAction func unwindToEmojiTableView(segue: UIStoryboardSegue) {
        guard segue.identifier == "saveUnwind",
            let sourceViewController = segue.source as? AddEditReservaTableViewController,
              let reserva = sourceViewController.reserv else { return }

        if let selectedIndexPath = reservaTableView.indexPathForSelectedRow {
            reservas[selectedIndexPath.row] = reserva
            reservaTableView.reloadRows(at: [selectedIndexPath], with: .none)
        } else {
            let newIndexPath = IndexPath(row: reservas.count, section: 0)
            reservas.append(reserva)
            reservaTableView.insertRows(at: [newIndexPath], with: .automatic)
        }
    }
}



