//
//  LoginViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 05/10/22.
//

import UIKit
import Amplify
import AWSAPIPlugin
import Combine
import Lottie

 class LoginViewController: UIViewController {
     
     var SignUpObject = SignUp(signUpSuccessful: false, confirmedSuccessful: false, addedToDataBase: false, isActive: false, resetConfirmation: false, isThereResetError: false, resetError: AuthError.unknown(""))
     var signObject2 = SignUp(signUpSuccessful: false, confirmedSuccessful: false, addedToDataBase: false, isActive: false, resetConfirmation: false, isThereResetError: false, resetError: AuthError.unknown(""))
     let defaults = UserDefaults.standard
     var timer: Timer?
     var timer2: Timer?

     @IBOutlet var usernameTextField: UITextField!
     @IBOutlet var passwordTextField: UITextField!
     
     @IBOutlet weak var usernameError: UILabel!
     @IBOutlet weak var newPasswordError: UILabel!
     
     @IBOutlet var resetView: UIView!
     @IBOutlet weak var userForReset: UITextField!
     @IBOutlet weak var sendCode: UIButton!
     @IBOutlet weak var codeMessage: UILabel!
     @IBOutlet weak var resetCode: UITextField!
     @IBOutlet weak var newPassword: UITextField!
     
     
     @IBOutlet weak var updatePassword: UIButton!
     
     @IBOutlet var successView: UIView!
     @IBOutlet weak var animation: AnimationView!
     

     override func viewDidLoad() {
         super.viewDidLoad()
         
         setUpAnimation()

         // Do any additional setup after loading the view.
         fetchCurrentAuthSession()
         UserDefaults.resetStandardUserDefaults()
     }

     @IBAction func signInButton(_ sender: Any) {
         guard let username:String = usernameTextField.text else {
             return
         }

         guard let password:String = passwordTextField.text else {
             return
         }

         signIn(username: username, password: password)
         
         timer2 = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true){ (timer2) in
             
             if self.signObject2.isThereResetError == true{
                 self.showAlert(title: "Alerta", message: self.signObject2.resetError!.errorDescription)
                 timer2.invalidate()
             }else{
                 self.fetchUser(username: username)
                 timer2.invalidate()
             }
              
             
             //self.fetchUser(username: username)
         }
         
         
         timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true){ (timer) in
             
             if self.SignUpObject.signUpSuccessful == true && self.SignUpObject.isActive == true{
                 let myTabBar = self.storyboard?.instantiateViewController(withIdentifier: "MainTabBarController") as! UITabBarController
                 myTabBar.modalPresentationStyle = .fullScreen
                 self.present(myTabBar, animated: true)
                 self.defaults.set(self.usernameTextField.text, forKey: "CurrentUser")
                 self.defaults.set(self.passwordTextField.text, forKey: "SecretPassword")
                 timer.invalidate()
             }
             
             if self.SignUpObject.isActive == false{
                 self.showAlert(title: "Alerta", message: "Esta cuenta ha sido desactivada")
                 timer.invalidate()
             }
         }
         
         
         fetchCurrentAuthSession()
     }
     
     
     

     func fetchCurrentAuthSession() {
         _ = Amplify.Auth.fetchAuthSession { result in
             switch result {
             case .success(let session):
                 print("Is user signed in - \(session.isSignedIn)")
             case .failure(let error):
                 print("Fetch session failed with error \(error)")
             }
         }
     }

     func signIn(username: String, password: String) {
         Amplify.Auth.signIn(username: username, password: password) { result in
             switch result {
             case .success:
                 print("Sign in succeeded")
                 self.SignUpObject.signUpSuccessful = true
                 self.signObject2.isThereResetError = false
             case .failure(let error):
                 print("Sign in failed \(error)")
                 self.signObject2.isThereResetError = true
                 self.signObject2.resetError = error
             }
         }
     }
     
     func fetchUser(username: String) {
         let todo = User.keys
         let predicate = todo.username == username
         let request = GraphQLRequest<User>.list(User.self, where: predicate)
         Amplify.API.query(request: request) { event in
             switch event {
             case .success(let result):
                 switch result {
                 case .success(let todos):
                     print("Successfully retrieved list of todos: \(todos)")
                     self.SignUpObject.isActive = todos[0].active
                 case .failure(let error):
                     print("Got failed result with \(error.errorDescription)")
                 }
             case .failure(let error):
                 print("Got failed event with error \(error)")
             }
         }
     }


   
     @IBAction func goToSignUp(_ sender: Any) {
         dismiss(animated: true)
     }
     
     func showAlert(title: String, message: String){
         let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
         alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {action in print("Dismiss")}))
         self.present(alert, animated:true, completion: nil)
     }
     
     
     
     @IBAction func resetPassword(_ sender: UIButton) {
         let backgroundView = self.view!
         resetView.layer.borderColor = UIColor.black.cgColor
         resetView.layer.borderWidth = 1
         resetView.layer.cornerRadius = 12
         backgroundView.addSubview(resetView)
         updatePassword.isEnabled = false
         sendCode.isEnabled = false
        
         resetView.center = backgroundView.center
     }
     
     func reset(username: String) {
         Amplify.Auth.resetPassword(for: username) { result in
             do {
                 let resetResult = try result.get()
                 switch resetResult.nextStep {
                 case .confirmResetPasswordWithCode(let deliveryDetails, let info):
                     print("Confirm reset password with code send to - \(deliveryDetails) \(String(describing: info))")
                     self.SignUpObject.resetConfirmation = true
                 case .done:
                     print("Reset completed")
                 }
             } catch {
                 print("Reset password failed with error \(error)")
             }
         }
     }
     
     
     @IBAction func cacelButt(_ sender: Any) {
         resetView.removeFromSuperview()
     }
     
     
     @IBAction func sendVerifCode(_ sender: UIButton) {
         reset(username: self.userForReset.text!)
         checkIfCodeWasSentSuccessfully()
     }
     
     
     @IBAction func updateNewPassword(_ sender: UIButton) {
         confirmResetPassword(username: userForReset.text!, newPassword: newPassword.text!, confirmationCode: resetCode.text!)
         checkIfResetIsConfirmed()
         
     }
     
     func checkIfResetIsConfirmed(){
         timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { (timer) in
             if self.SignUpObject.isThereResetError == true{
                 self.showAlert(title: "Alerta", message: self.SignUpObject.resetError!.errorDescription)
             }else{
                 
                 self.resetView.removeFromSuperview()
                 let backgroundView = self.view!
                 self.successView.layer.borderColor = UIColor.black.cgColor
                 self.successView.layer.borderWidth = 1
                 self.successView.layer.cornerRadius = 12
                 backgroundView.addSubview(self.successView)
                 self.successView.center = backgroundView.center
             }
             
             timer.invalidate()
         }
     }
     
     
     @IBAction func userchanged(_ sender: UITextField) {
         if let username = userForReset.text{
             if let errorMessage = SignUp.invalidUsername(username){
                 usernameError.text = errorMessage
                 usernameError.isHidden = false
             }else {
                 usernameError.isHidden = true
             }
         }
         
         sendCode.isEnabled = true
     }
     
     func checkIfCodeWasSentSuccessfully(){
         timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { (timer) in
             if self.SignUpObject.resetConfirmation == true{
                 self.codeMessage.isHidden = false
             }else{
                 self.shakeTextField(textField: self.userForReset)
             }
             
             timer.invalidate()
         }
     }
     
     
     @IBAction func newPassword(_ sender: Any) {
         if let password = newPassword.text{
             if let errorMessage = SignUp.invalidPassword(password){
                 newPasswordError.text = errorMessage
                 newPasswordError.isHidden = false
             }else {
                 newPasswordError.isHidden = true
             }
         }
         
         updatePassword.isEnabled = true
     }
     
     func confirmResetPassword(
         username: String,
         newPassword: String,
         confirmationCode: String
     ) {
         Amplify.Auth.confirmResetPassword(
             for: username,
             with: newPassword,
             confirmationCode: confirmationCode
         ) { result in
             switch result {
             case .success:
                 print("Password reset confirmed")
                 self.SignUpObject.isThereResetError = false
             case .failure(let error):
                 print("Reset password failed with error \(error)")
                 self.SignUpObject.isThereResetError = true
                 self.SignUpObject.resetError = error
             }
         }
     }
     
     
     
     @IBAction func dismissSuccess(_ sender: Any) {
         successView.removeFromSuperview()
     }
     
     func setUpAnimation(){
         let subAnimationView = AnimationView(name: "passwordChanged")
         animation.contentMode = .scaleAspectFit
         animation.loopMode = .playOnce
         animation.animationSpeed = 1.0
         animation.addSubview(subAnimationView)
         subAnimationView.frame = animation.bounds
         subAnimationView.play()
     }
     
     func shakeTextField(textField: UITextField){
         let animation = CABasicAnimation(keyPath: "position")
         animation.duration = 0.07
         animation.repeatCount = 3
         animation.autoreverses = true
         animation.fromValue = NSValue(cgPoint: CGPoint(x: textField.center.x - 10, y: textField.center.y))
         animation.toValue = NSValue(cgPoint: CGPoint(x: textField.center.x + 10, y: textField.center.y))
         textField.layer.add(animation, forKey: "position")

         textField.attributedPlaceholder = NSAttributedString(string: textField.placeholder ?? "",
                                                              attributes: [NSAttributedString.Key.foregroundColor: UIColor.red])

     }
     
     
 }
