//
//  SignUpViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 05/10/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine

 class SignUpViewController: UIViewController {
    
     let defaults = UserDefaults.standard
     var timer: Timer?
     var SignUpObject = SignUp(signUpSuccessful: false, confirmedSuccessful: false, addedToDataBase: false, isActive: false)
     
     @IBOutlet var popUpView: UIView!
     @IBOutlet var termsAndConditions: UIView!
     @IBOutlet weak var termsAccept: UIButton!
     @IBOutlet weak var checkBox: UIButton!
     
     @IBOutlet weak var nameOfuser: UITextField!
     @IBOutlet weak var nameOfUserError: UILabel!
     
     @IBOutlet weak var userMail: UITextField!
     @IBOutlet weak var mailError: UILabel!
     
     @IBOutlet weak var userPassword: UITextField!
     @IBOutlet weak var passwordError: UILabel!
     
     @IBOutlet weak var username: UITextField!
     @IBOutlet weak var usernameError: UILabel!
     
     @IBOutlet weak var crearCuentaButton: UIButton!
     @IBOutlet var verificationCode: UITextField!
    

     override func viewDidLoad() {
         super.viewDidLoad()

         resetFormulario()
         SignUp.signOutLocally()
         UserDefaults.resetStandardUserDefaults()
     }
     
     func resetFormulario(){
         crearCuentaButton.isEnabled = false
         
         nameOfUserError.isHidden = false
         mailError.isHidden = false
         passwordError.isHidden = false
         usernameError.isHidden = false
         
         nameOfUserError.text = "*"
         mailError.text = "*"
         passwordError.text = "*"
         usernameError.text = "*"
         
         nameOfuser.text = ""
         userMail.text = ""
         userPassword.text = ""
         username.text = ""
         
     }
     
     
     @IBAction func nameOfUserchanged(_ sender: Any) {
         if let nameUser = nameOfuser.text{
             if let errorMessage = SignUp.invalidNameOfUser(nameUser){
                 nameOfUserError.text = errorMessage
                 nameOfUserError.isHidden = false
             }else{
                 nameOfUserError.isHidden = true
             }
         }
         
         checkValidForm()
     }
     
     
     @IBAction func mailChanged(_ sender: Any) {
         
         if let email = userMail.text{
             if let errorMessage = SignUp.invalidEmail(email){
                 mailError.text = errorMessage
                 mailError.isHidden = false
             }else{
                 mailError.isHidden = true
             }
         }
         
         checkValidForm()
     }
     
     
     @IBAction func passwordChanged(_ sender: Any) {
         if let password = userPassword.text{
             if let errorMessage = SignUp.invalidPassword(password){
                 passwordError.text = errorMessage
                 passwordError.isHidden = false
             }else{
                 passwordError.isHidden = true
             }
         }
         
         checkValidForm()
     }
     
  
     @IBAction func usernameChanged(_ sender: Any) {
         if let username = username.text{
             if let errorMessage = SignUp.invalidUsername(username){
                 usernameError.text = errorMessage
                 usernameError.isHidden = false
             }else{
                 usernameError.isHidden = true
             }
         }
         
         checkValidForm()
     }
     
     func checkValidForm(){
         if nameOfUserError.isHidden && mailError.isHidden && passwordError.isHidden && usernameError.isHidden {
             crearCuentaButton.isEnabled = true
         }else{
             crearCuentaButton.isEnabled = false
         }
     }
     
        
     @IBAction func checkBoxCheck(_ sender: UIButton) {
         if sender.isSelected{
             sender.isSelected = false
             //print("Estoy off")
             
             termsAccept.isEnabled = false
             
         }else{
             sender.isSelected = true
             termsAccept.isEnabled = true
             //print("Estoy on")
         }
     }
     
     
     
     @IBAction func acceptTerms(_ sender: Any) {
         let backgroundView = self.view!
         backgroundView.addSubview(popUpView)
         
         popUpView.layer.borderColor = UIColor.black.cgColor
         popUpView.layer.borderWidth = 1
         popUpView.layer.cornerRadius = 8
         
         popUpView.center = backgroundView.center
         termsAndConditions.isHidden = true
         
     }
     
    

     @IBAction func createAccount(_ sender: Any) {
         
         let name = nameOfuser.text!
         let lastName = name.components(separatedBy: " ")
         let mail = userMail.text!
         let pwd = userPassword.text!
         let username = username.text!
         
         
         signUp(username: username, password: pwd, email: mail, familyName: lastName[1], name: lastName[0])
         
         
         let backgroundView = self.view!
         termsAndConditions.layer.borderColor = UIColor.black.cgColor
         termsAndConditions.layer.borderWidth = 1
         backgroundView.addSubview(termsAndConditions)
         termsAccept.isEnabled = false
        
         termsAndConditions.center = backgroundView.center
         
         //resetFormulario()
         
     }
     
     
     @IBAction func verify(_ sender: Any) {
         let userName = username.text!
         let code = verificationCode.text!
         confirmSignUp(for: userName, with: code)
         
         checkIfverifiedSuccessful(username: userName, passwrod: userPassword.text!)
         
     }
     
     func checkIfverifiedSuccessful(username: String, passwrod: String){
         timer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { (timer) in
             if self.SignUpObject.confirmedSuccessful{
                 SignUp.signIn(username: username, password: passwrod)
                 let myTabBar = self.storyboard?.instantiateViewController(withIdentifier: "MainTabBarController") as! UITabBarController
                 myTabBar.modalPresentationStyle = .fullScreen
                 self.present(myTabBar, animated: true)
                 
                 let name = self.nameOfuser.text!
                 let lastName = name.components(separatedBy: " ")
                 
                 self.defaults.set(username, forKey: "CurrentUser")
                 self.createUserDB(username: username, name: lastName[0], surname: lastName[1], email: self.userMail.text!, verified: true, active: true, type: UserType(rawValue: "USER")!)
                 
             }else{
                 self.shakeTextField(textField: self.verificationCode)
             }
             
             
             timer.invalidate()
         }
     }


     func signUp(username: String, password: String, email: String, familyName: String, name: String){
         let userAttributes = [AuthUserAttribute(.email, value: email), AuthUserAttribute(.familyName, value: familyName), AuthUserAttribute(.name, value: name)]
         let options = AuthSignUpRequest.Options(userAttributes: userAttributes)
         Amplify.Auth.signUp(username: username, password: password, options: options) { result in
             switch result {
             case .success(let signUpResult):
                 if case let .confirmUser(deliveryDetails, _) = signUpResult.nextStep {
                     print("Delivery details \(String(describing: deliveryDetails))")
                     self.SignUpObject.signUpSuccessful = true
                     
                 } else {
                     print("SignUp Complete")
                     self.SignUpObject.signUpSuccessful = true
                 }
             case .failure(let error):
                 print("An error occurred while registering a user \(error)")
             }
         }
     }

     func confirmSignUp(for username: String, with confirmationCode: String){
         Amplify.Auth.confirmSignUp(for: username, confirmationCode: confirmationCode) { result in
             switch result {
             case .success:
                 print("Confirm signUp succeeded")
                 self.SignUpObject.confirmedSuccessful = true
             case .failure(let error):
                 print("An error occurred while confirming sign up \(error.errorDescription)")
                 self.SignUpObject.confirmedSuccessful = false
             }
             
         }
     }
     
     func createUserDB(username: String, name: String, surname: String, email: String, verified: Bool, active: Bool, type: UserType){
         let userToCreate = User(username: username, name: name, surname: surname, email: email, type: type, verified: verified, active: verified)
         Amplify.API.mutate(request: .create(userToCreate)) { event in
             switch event {
             case .success(let result):
                 switch result{
                 case .success(let user):
                     print("Successfully added user to database: \(user)")
                     self.SignUpObject.addedToDataBase = true
                 case .failure(let error):
                     print("Got failed result with: \(error.errorDescription)")
                 }
             case .failure(let error):
                 print("Got failed event with error \(error)")
             }
         }
         
     }
     
     func shakeTextField(textField: UITextField){
         let animation = CABasicAnimation(keyPath: "position")
         animation.duration = 0.07
         animation.repeatCount = 3
         animation.autoreverses = true
         animation.fromValue = NSValue(cgPoint: CGPoint(x: textField.center.x - 10, y: textField.center.y))
         animation.toValue = NSValue(cgPoint: CGPoint(x: textField.center.x + 10, y: textField.center.y))
         textField.layer.add(animation, forKey: "position")

         textField.attributedPlaceholder = NSAttributedString(string: textField.placeholder ?? "",
                                                              attributes: [NSAttributedString.Key.foregroundColor: UIColor.red])

     }


 }


extension UIView{
    func shake() {
           let animation = CAKeyframeAnimation(keyPath: "transform.translation.x")
           animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
           animation.duration = 0.6
           animation.values = [-20.0, 20.0, -20.0, 20.0, -10.0, 10.0, -5.0, 5.0, 0.0 ]
           layer.add(animation, forKey: "shake")
       }
}
