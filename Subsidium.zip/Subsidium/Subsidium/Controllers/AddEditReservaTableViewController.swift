//
//  AddEditReservaTableViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 30/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine
import FSCalendar

class AddEditReservaTableViewController: UITableViewController, FSCalendarDelegate, FSCalendarDataSource, FSCalendarDelegateAppearance{
    
    @IBOutlet weak var roomDurationText: UITextField!
    
    var reserv: Reservation?
    let defaults = UserDefaults.standard
    let datePickerFecha = UIDatePicker()
    var newDayIndex: Int = 0
    var selected: String = ""
    var disabledDates: [String] = []
    var formatter = DateFormatter()
    var datesFromQuery: [ResDur] = []
    var formatterHours = DateFormatter()
    
    @IBOutlet weak var cal: FSCalendar!
    
    let duracionesNoSeMueve = ["30", "60", "90", "120"]
    var duraMin = ["30", "60", "90", "120"]
    
    let duraPicker = UIPickerView()
    
    var horas = ["07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00"]
    var duraciones = ["5 días", "10 días", "15 días", "20 días", "25 días", "30 días"]
    var d = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"]
    let pickerView = UIPickerView()
    let noSeMueve = ["07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00"]
    var hoursFromQuery: [ResTimes] = []
    
    @IBOutlet weak var serviceTitle: UILabel!
    @IBOutlet weak var textFecha: UITextField!
    @IBOutlet weak var textHora: UITextField!
    
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    init?(coder: NSCoder, r: Reservation?) {
        self.reserv = r
        super.init(coder: coder)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @IBAction func tapScreen(_ sender: UITapGestureRecognizer) {
        textFecha.resignFirstResponder()
        textHora.resignFirstResponder()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        if let reserv = reserv{
            
            if reserv.deviceID == nil && reserv.licenceID == nil{
                serviceTitle.text = getRoomName(reservation: reserv)
                textFecha.text = reserv.reservationDate
                textHora.text = reserv.reservationTime
                
                hoursFromQuery = getRoomOccupiedDates()
                
                duraPicker.delegate = self
                duraPicker.dataSource = self
                
                roomDurationText.inputView = duraPicker
                roomDurationText.inputAccessoryView = createToolBarDuraciones()
                
            }else if reserv.roomID == nil && reserv.licenceID == nil{
                roomDurationText.isHidden = true
                serviceTitle.text = getDeviceName(reservation: reserv)
                textFecha.text = reserv.reservationDate
                
                datesFromQuery = getHardwareOccupiedDates()
                
                for i in datesFromQuery{
                    disabledDates.append(i.date)
                    formatter.dateFormat = "yyyy-MM-dd"
                    var new = Calendar.current.date(byAdding: .day, value: 1, to: formatter.date(from: i.date)!)
                    let formatted = formatter.string(from: new!)
                    print(formatted)
                    disabledDates.append(formatted)
                    for _ in 1...i.duration-2{
                        new = Calendar.current.date(byAdding: .day, value: 1, to: new!)
                        let formatted = formatter.string(from: new!)
                        print(formatted)
                        disabledDates.append(formatted)
                    }
                }

                textHora.text = reserv.reservationDuration?.description
            }
            
            //createDatePicker()
            //createPicker()
            
            cal.register(FSCalendarCell.self, forCellReuseIdentifier: "CELL")
            cal.scrollDirection = .horizontal
            cal.appearance.todayColor = .systemGreen
            
            cal.delegate = self
            cal.dataSource = self
            
            title = "Editar reserva"
        }
        
        updateSaveButtonState()

    }
    
    func updateSaveButtonState() {
        let desc1 = textFecha.text ?? ""
        let desc2 = textHora.text ?? ""
        saveButton.isEnabled = !desc1.isEmpty && !desc2.isEmpty
    }
    
    
    @IBAction func textEditingChanged(_ sender: UITextField){
        updateSaveButtonState()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "saveUnwind" else { return }
        let desc1 = textFecha.text ?? ""
        let desc2 = textHora.text ?? ""
        
        if reserv?.deviceID == nil && reserv?.licenceID == nil{
            
            var duracionFinal: Int = 0
            
            if roomDurationText.text == "30"{
                duracionFinal = 30
            }else if roomDurationText.text == "60"{
                duracionFinal = 60
            }else if roomDurationText.text == "90"{
                duracionFinal = 90
            }else if roomDurationText.text == "120"{
                duracionFinal = 120
            }
            
            reserv = Reservation(id: reserv!.id, userID: defaults.string(forKey: "CurrentUserId")!, deviceID: reserv?.deviceID, licenceID: reserv?.licenceID, roomID: reserv?.roomID, reservationDate: desc1, reservationTime: desc2, reservationDuration: duracionFinal, state: reserv!.state)
            
            updateReservationDB(resToUpdate: reserv!)
            
        }else if reserv?.roomID == nil && reserv?.licenceID == nil{
            
                
            reserv = Reservation(id: reserv!.id, userID: defaults.string(forKey: "CurrentUserId")!, deviceID: reserv?.deviceID, licenceID: reserv?.licenceID, roomID: reserv?.roomID, reservationDate: desc1, reservationTime: reserv?.reservationTime, reservationDuration: Int(desc2), state: reserv!.state)
            
            updateReservationDB(resToUpdate: reserv!)
        }
        
    }
    
    func updateReservationDB(resToUpdate: Reservation){
        Amplify.API.mutate(request: .update(resToUpdate)) { event in
            switch event {
            case .success(let result):
                switch result{
                case .success(let reservation):
                    print("Successfully updated reservation in database: \(reservation)")
                case .failure(let error):
                    print("Got failed result with: \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }

}

extension  AddEditReservaTableViewController: UIPickerViewDelegate, UIPickerViewDataSource{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        var count: Int = 0
        
        if reserv?.deviceID == nil && reserv?.licenceID == nil{
            if textHora.isEditing{
                count = horas.count
            }else{
                if roomDurationText.isEditing{
                    count = duraMin.count
                }
            }
            
            //count = horas.count
        }else if reserv?.roomID == nil && reserv?.licenceID == nil{
            count = duraciones.count
        }
        
        return count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        var selected: String = ""
        
        if reserv?.deviceID == nil && reserv?.licenceID == nil{
            if textHora.isEditing{
                selected = horas[row]
            }else if roomDurationText.isEditing{
                selected = duraMin[row]
            }
            //selected = horas[row]
        }else if reserv?.roomID == nil && reserv?.licenceID == nil{
            selected = duraciones[row]
            self.newDayIndex = row
        }
        
        
        return selected
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if reserv?.deviceID == nil && reserv?.licenceID == nil{
            if pickerView == duraPicker{
                self.roomDurationText.text = self.duraMin[row]
            }else{
                self.textHora.text = self.horas[row]
                updateDuraciones(input: self.horas[row])
            }
            //self.textHora.text = self.horas[row]
        }else if reserv?.roomID == nil && reserv?.licenceID == nil{
            self.textHora.text = self.duraciones[row]
        }
    }
    
    
    func createToolBar() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createToolBarPicker() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPicker))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createToolBarDuraciones() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPickerDuraPicker))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createDatePicker(){
        datePickerFecha.preferredDatePickerStyle = .inline
        datePickerFecha.datePickerMode = .date
        textFecha.inputView = datePickerFecha
        
        textFecha.inputAccessoryView = createToolBar()
    }
    
    func createPicker(){
        pickerView.delegate = self
        pickerView.dataSource = self
        
        textHora.inputView = pickerView
        textHora.inputAccessoryView = createToolBarPicker()
    }
    
    @objc func donePressed(){
        let dateFormatter = DateFormatter()
        
        if reserv?.deviceID == nil && reserv?.licenceID == nil{
            dateFormatter.dateFormat = "yyyy-MM-dd"
        }else if reserv?.roomID == nil && reserv?.licenceID == nil{
            dateFormatter.dateFormat = "yyyy-MM-dd"
        }
        
        self.textFecha.text = dateFormatter.string(from: datePickerFecha.date)
        
        self.view.endEditing(true)
    }
    
    @objc func donePressedPicker(){
        let row = self.pickerView.selectedRow(inComponent: 0)
        self.pickerView.selectRow(row, inComponent: 0, animated: false)
        
        if reserv?.deviceID == nil && reserv?.licenceID == nil{
            self.textHora.text = self.horas[row]
        }else if reserv?.roomID == nil && reserv?.licenceID == nil{
            self.textHora.text = self.duraciones[row]
        }
        
        self.view.endEditing(true)
    }
    
    
    @objc func donePressedPickerDuraPicker(){
        let row = self.duraPicker.selectedRow(inComponent: 0)
        self.duraPicker.selectRow(row, inComponent: 0, animated: false)
        self.roomDurationText.text = self.duraMin[row]
        
        self.view.endEditing(true)
    }
    
    func getRoomName(reservation: Reservation) -> String{
        var link = ""
        let semaphore = DispatchSemaphore(value: 0)

        Amplify.API.query(request: .get(Room.self, byId: reservation.roomID!)) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todo):
                        guard let todo = todo else {
                            print("Could not find todo")
                            return
                        }
                        print("Successfully retrieved Room name: \(todo.name)")
                        link = todo.building + " " + todo.name
                        semaphore.signal()
                        
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        
        return link
    }
    
    func getDeviceName(reservation: Reservation) -> String{
        var link = ""
        let semaphore = DispatchSemaphore(value: 0)

        Amplify.API.query(request: .get(Device.self, byId: reservation.deviceID!)) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todo):
                        guard let todo = todo else {
                            print("Could not find todo")
                            return
                        }
                        print("Successfully retrieved Device name: \(todo.name)")
                        link = todo.name
                        semaphore.signal()
                        
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        
        return link
    }
    
    func minimumDate(for calendar: FSCalendar) -> Date {
        return Date()
    }
    
    func maximumDate(for calendar: FSCalendar) -> Date {
        return Calendar.current.date(byAdding: .month, value: 3, to: Date())!
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        formatter.dateFormat = "yyyy-MM-dd"
        self.selected = formatter.string(from: date)
        self.textFecha.text = formatter.string(from: date)
        
        if reserv?.roomID == nil && reserv?.licenceID == nil{
            createPickerDevices(input: formatter.string(from: date))
        }else if reserv?.deviceID == nil && reserv?.licenceID == nil{
            createPickerRoom(input: formatter.string(from: date))
        }
        
        
    }
    
    func calendar(_ calendar: FSCalendar, cellFor date: Date, at position: FSCalendarMonthPosition) -> FSCalendarCell {
        let cell: FSCalendarCell = calendar.dequeueReusableCell(withIdentifier: "CELL", for: date, at: position)
        let dateFromStringFormatter = DateFormatter()
        dateFromStringFormatter.dateFormat = "yyyy-MM-dd"
        let calendarDate = dateFromStringFormatter.string(from: date)
        
        if disabledDates.contains(calendarDate) {
            cell.isUserInteractionEnabled = false
        }else{
            cell.isUserInteractionEnabled = true
        }
        
        return cell
    }
        
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleDefaultColorFor date: Date) -> UIColor? {
        formatter.dateFormat = "yyyy-MM-dd"
        
        for i in disabledDates{
            guard let excluded = formatter.date(from: i) else { return nil }
            if date.compare(excluded) == .orderedSame {
                return .red
            }
        }
        
        return nil
    }
    
    func getHardwareOccupiedDates() -> ([ResDur]){
        
        var values: [ResDur] = []
        let semaphore = DispatchSemaphore(value: 0)
        let todo = Reservation.keys
        let predicate = todo.deviceID == reserv?.deviceID && todo.id != reserv?.id
        let request = GraphQLRequest<Reservation>.list(Reservation.self, where: predicate)
        Amplify.API.query(request: request) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todos):
                        print("Successfully retrieved list of todos: \(todos)")
                        for i in todos{
                            let val = ResDur(date: i.reservationDate, duration: i.reservationDuration ?? 0)
                            values.append(val)
                        }
                        semaphore.signal()
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        return values
    }
    
    func createPickerDevices(input: String){
        
        formatter.dateFormat = "yyyy-MM-dd"
        var counter: Int = 0
        var added = Calendar.current.date(byAdding: .day, value: 1, to: formatter.date(from: input)!)
        let addedFormated = formatter.string(from: added!)
        if disabledDates.contains(addedFormated){
            self.duraciones = ["0"]
        }else{
            for _ in 1...90{
                added = Calendar.current.date(byAdding: .day, value: 1, to: added!)
                if disabledDates.contains(formatter.string(from: added!)){
                    break
                }else{
                    counter += 1
                }
            }
            
            if counter > 15{
                counter = 14
            }
            
            self.duraciones = Array(d[0...counter])
        }
        
        pickerView.delegate = self
        pickerView.dataSource = self
        
        textHora.inputView = pickerView
        textHora.inputAccessoryView = createToolBarPicker()

        
    }
    
    func getRoomOccupiedDates() -> ([ResTimes]){
        var values: [ResTimes] = []
        let semaphore = DispatchSemaphore(value: 0)
        let todo = Reservation.keys
        let predicate = todo.roomID == reserv?.roomID && todo.id != reserv?.id
        let request = GraphQLRequest<Reservation>.list(Reservation.self, where: predicate)
        Amplify.API.query(request: request) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todos):
                        print("Successfully retrieved list of Reservations: \(todos)")
                        for i in todos{
                            let val = ResTimes(resDate: i.reservationDate, resHour: i.reservationTime ?? "00:00", resDuration: i.reservationDuration)
                            values.append(val)
                        }
                        semaphore.signal()
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        return values
        
    }
    
    func createPickerRoom(input: String){
        
        formatter.dateFormat = "yyyy-MM-dd"
        formatterHours.dateFormat = "HH:mm"
        
        horas = noSeMueve
        var temp = noSeMueve
        
        for i in hoursFromQuery{
            if input == i.resDate{
                //temp = temp.filter(){$0 != i.resHour}
                print(i.resHour)
                
                //var tempAdded: [String] = []
                var len: Int = 0
                
                if i.resDuration == 30{
                    len = 1
                }else if i.resDuration == 60{
                    len = 2
                }else if i.resDuration == 90{
                    len = 3
                }else if i.resDuration == 120{
                    len = 4
                }
                
                let current = formatterHours.date(from: i.resHour)
                var new = current
                
                for _ in 1...len{
                    new = Calendar.current.date(byAdding: .minute, value: 30, to: new!)
                    let generated = formatterHours.string(from: new!)
                    print(generated)
                    temp = temp.filter(){$0 != generated}
                }
                
                
            }
        }
        
        self.horas = temp
        
        
        
        pickerView.delegate = self
        pickerView.dataSource = self
        
        textHora.inputView = pickerView
        textHora.inputAccessoryView = createToolBarPicker()
    }
    
    func updateDuraciones(input: String){
        
        print("Raw input -----> \(input)")
        formatterHours.dateFormat = "HH:mm"
        let current = formatterHours.date(from: input)
        
        let forprint = formatterHours.string(from: current!)
        print("Current -----> \(forprint)")
        
        var counter = 0
        var new = current
        
        for i in 1...4{
            new = Calendar.current.date(byAdding: .minute, value: 30, to: new!)
            let generated = formatterHours.string(from: new!)
            
            print("Generated ---> \(generated) in round \(i)")
            
            if horas.contains(generated){
                print("True, horas contains --------> \(generated)")
                counter += 1
            }else{
                break
            }
            
        }
        
        
        if counter == 0{
            self.duraMin = ["0"]
        }else if counter == 1{
            self.duraMin = ["30"]
        }else if counter == 2{
            self.duraMin = ["30", "60"]
        }else if counter == 3{
            self.duraMin = ["30", "60", "90"]
        }else if counter == 4{
            self.duraMin = ["30", "60", "90", "120"]
        }
    }
    
    
    
    
    
}

