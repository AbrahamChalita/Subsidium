//
//  StaticStarredViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 09/10/22.
//

import UIKit

class StaticStarredViewController: UIViewController {


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  
    @IBAction func moveToLoginSignUp(_ sender: UIButton) {
        tabBarController?.selectedIndex = 3
    }
    
}
