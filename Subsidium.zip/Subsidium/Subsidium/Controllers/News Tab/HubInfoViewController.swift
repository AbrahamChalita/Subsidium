//
//  HubInfoViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 18/10/22.
//

import UIKit

class HubInfoViewController: UIViewController {

    @IBOutlet weak var fechaActual: UILabel!
    let date = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE d, MMMM yyyy"
        fechaActual.text = dateFormatter.string(from: date)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
