//
//  NewsExpandedViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine

class NewsExpandedViewController: UIViewController {
    
    @IBOutlet weak var ExpandedImageNews: UIImageView!
    @IBOutlet weak var ExpandedTitleNews: UILabel!
    @IBOutlet weak var ExpandedContent: UITextView!
    
    
    var tituloNoticia = ""
    var contenidoNotica = ""
    
    var noticiaActual: New = New(title: "", description: "", date_published: "", image: "", content: "")
    
    func getImageURL(noticia: New) -> URL{
        var link = URL(string: "google.com")
        let semaphore = DispatchSemaphore(value: 0)
        
        Amplify.Storage.getURL(key: noticia.image) { event in
            switch event {
            case let .success(url):
                print("Completed, retrieved url correctly")
                link = url
                semaphore.signal()
            case let .failure(storageError):
                print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
            }
        }
        
        semaphore.wait()
        
        return link!
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let urlString = getImageURL(noticia: noticiaActual)
        ExpandedImageNews.downloaded(from: urlString)
        ExpandedTitleNews.text = noticiaActual.title
        ExpandedContent.text = noticiaActual.content
        

    }
    

}
