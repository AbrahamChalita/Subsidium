//
//  NewsViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine

enum NewsError:Error, LocalizedError{
    case itemNotFound
    case decodeError
}

public class NewsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let defaults = UserDefaults.standard
    var user: [User] = []
    var link: String = ""
    @IBOutlet weak var currentDate: UILabel!
    let date = Date()
    
    @IBAction func HubInfoButton(_ sender: UIButton) {
        
    }
    
    @IBOutlet weak var TableView: UITableView!
    
    var noticias: [New] = []
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE d, MMMM yyyy"
        currentDate.text = dateFormatter.string(from: date)
        
    
        TableView.delegate = self
        TableView.dataSource = self
        
        fetchDataNews()
        listUsers()
        
    }

    
    func fetchDataNews(){
        // Predicate functions as query filters
        //let noticia = New.keys
        //let predicate = noticia.title == "Notica 1" && noticia.description == "Esta es la descripcion"
        let request = GraphQLRequest<New>.list(New.self)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let lista):
                    print("Successfully retrieved list of News: \(lista)")
                    self.noticias = lista
                    self.updateUI(with: lista)
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
        
    }
    
    func fecthDataNewsTest() async throws -> [New]{
        
        var noticiasFetcheadas: [New] = []
        let semaphore = DispatchSemaphore(value: 0)
        let request = GraphQLRequest<New>.list(New.self)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let lista):
                    print("Successfully retrieved list of News: \(lista)")
                    noticiasFetcheadas = lista
                    semaphore.signal()
                    
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
                //throw NewsError.itemNotFound
            }
        }
        semaphore.wait()
        
        if noticiasFetcheadas.isEmpty{
            throw NewsError.itemNotFound
        }
        
        return noticiasFetcheadas
        
    }
    
    func updateUI(with noticias: [New]){
        DispatchQueue.main.async {
            self.noticias = self.noticias
            self.TableView.reloadData()
        }
    }
    
    
    func listUsers() {
        let todo = User.keys
        let predicate = todo.username == defaults.string(forKey: "CurrentUser")
    
        let request = GraphQLRequest<User>.list(User.self, where: predicate)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let todos):
                    print("Successfully retrieved user: \(todos)")
                    self.user = todos
                    self.updateUIUser(with: todos)
                    
                    if !todos.isEmpty{
                        self.defaults.set(todos[0].id, forKey: "CurrentUserId")
                        self.defaults.set(todos[0].email, forKey: "CurrentUserMail")
                        self.defaults.set(todos[0].name, forKey: "CurrentUserName")
                        self.defaults.set(todos[0].surname, forKey: "CurrentUserLastName")
                        self.defaults.set(todos[0].active, forKey: "CurrentUserActive")
                        self.defaults.set(todos[0].verified, forKey: "CurrentUserVerified")
                        self.defaults.set(todos[0].type?.rawValue, forKey: "CurrentUserType")
                    }
                    
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    func updateUIUser(with usuarios: [User]){
        DispatchQueue.main.async {
            self.user = self.user
        }
    }
        
}


extension NewsViewController{
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return noticias.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let noticia = noticias[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "newsCell") as! NewsTableViewCell
        
        cell.setNoticia(noticia: noticia)
        
        return cell
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "NewsExpandedViewController") as? NewsExpandedViewController
        
        vc?.noticiaActual = noticias[indexPath.row]
        
        self.navigationController?.pushViewController(vc!, animated: true)
    }

}





	
