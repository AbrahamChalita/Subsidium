//
//  NewsTableViewCell.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class NewsTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var newsImageView: UIImageView!
    @IBOutlet weak var newsTitle: UILabel!
    @IBOutlet weak var newsDescription: UILabel!
    @IBOutlet weak var newsDate: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func getImageURL(noticia: New) -> URL{
        var link = URL(string: "google.com")
        let semaphore = DispatchSemaphore(value: 0)
        
        Amplify.Storage.getURL(key: noticia.image) { event in
            switch event {
            case let .success(url):
                print("Completed, retrieved url correctly")
                link = url
                semaphore.signal()
            case let .failure(storageError):
                print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
            }
        }
        
        semaphore.wait()
        
        return link!
    }
    
    func setNoticia(noticia: New){
        
        let urlString = getImageURL(noticia: noticia)
        newsImageView.downloaded(from: urlString)
        newsTitle.text = noticia.title
        newsDescription.text = noticia.description
        newsDate.text = noticia.date_published
    }
    
   
}

extension UIImageView {
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}

