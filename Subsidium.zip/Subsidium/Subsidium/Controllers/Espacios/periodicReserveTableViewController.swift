//
//  periodicReserveTableViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 02/10/22.
//

import UIKit
import MessageUI
import Amplify
import AWSAPIPlugin

class periodicReserveTableViewController: UITableViewController {
    
    let defaults = UserDefaults.standard
    
    let horas1 = ["7:00", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00"]
    let horas2 = ["7:00", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00"]
    
    let horaInicioPickerView = UIPickerView()
    let horaFinalPickerView = UIPickerView()
    
    let fechaInicioDatePicker = UIDatePicker()
    let fechaFinalDatePicker = UIDatePicker()
    
    @IBOutlet weak var horaInicio: UITextField!
    @IBOutlet weak var horaFinal: UITextField!
    @IBOutlet weak var repetirCada: UITextField!
    @IBOutlet weak var fechaInicio: UITextField!
    @IBOutlet weak var fechaFinal: UITextField!
    
    @IBOutlet weak var razon: UITextView!
    @IBOutlet weak var sendButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        razon.layer.cornerRadius = 6
        razon.layer.borderWidth = 1
        razon.layer.borderColor = UIColor.black.cgColor
        
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(hideKeyboard)))
        
        createPicker()
        createDatePicker()

        
    }
    
    
    @IBAction func sendInfo(_ sender: Any) {
        showMailComposer()
    }
    
    func showMailComposer(){
        guard MFMailComposeViewController.canSendMail() else {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "authorizationViewController") as? authorizationViewController
            vc?.modalPresentationStyle = .popover
            self.present(vc!, animated: true)
            return
        }
        
        let composer = MFMailComposeViewController()
        composer.mailComposeDelegate = self
        composer.setToRecipients(["ferrari458chalita@hotmail.com", "a01653879@tec.mx", "a01653869@tec.mx"])
        composer.setSubject("Petición de reserva periódica")
        composer.setMessageBody("Como usuario: \(String(describing: defaults.string(forKey: "CurrentUserId"))), solicito una reserva periódica iniciando el \(fechaInicio.text!), hasta \(fechaFinal.text!). Seria repetido cada \(repetirCada.text!), de \(horaInicio.text!) a \(horaFinal.text!). La razón es porque: \(razon.text!). '\n' '\n' A su consideración, gracias.", isHTML: false)
        
        present(composer, animated: true)
        
    }
    
}

extension periodicReserveTableViewController: UIPickerViewDelegate, UIPickerViewDataSource, MFMailComposeViewControllerDelegate{
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        if let _ = error{
            controller.dismiss(animated: true)
        }
        
        switch result{
        case.cancelled:
            print("Cancelled")
        case .failed:
            print("Failed to send")
        case .saved:
            print("Saved")
        case .sent:
            print("Email sent")
        @unknown default:
            print("Unknown error")
        }
        
        controller.dismiss(animated: true)
    }
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        var comp: Int?
        if pickerView == horaInicioPickerView{
            comp = horas1.count
        }else if pickerView == horaFinalPickerView{
            comp = horas2.count
        }
        
        return comp ?? 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        var res: String?
        
        if pickerView == horaInicioPickerView{
            res = horas1[row]
        }else if pickerView == horaFinalPickerView{
            res = horas2[row]
        }
        
        return res
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == horaInicioPickerView{
            self.horaInicio.text = self.horas1[row]
        }else if pickerView == horaFinalPickerView{
            self.horaFinal.text = self.horas2[row]
        }
    }
    
     
    
    func createToolBarPickerInicio() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPickerInicio))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createToolBarPickerFinal() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPickerFinal))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createToolBarDateInicio() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedDateInicio))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createToolBarDateFinal() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedDateFinal))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createPicker(){
        horaInicioPickerView.delegate = self
        horaInicioPickerView.dataSource = self
        
        horaFinalPickerView.delegate = self
        horaFinalPickerView.dataSource = self
        
        horaFinal.inputView = horaFinalPickerView
        horaFinal.inputAccessoryView = createToolBarPickerFinal()
        
        horaInicio.inputView = horaInicioPickerView
        horaInicio.inputAccessoryView = createToolBarPickerInicio()
    }
    
    func createDatePicker(){
        fechaInicioDatePicker.preferredDatePickerStyle = .inline
        fechaFinalDatePicker.preferredDatePickerStyle = .inline
        
        fechaInicioDatePicker.datePickerMode = .date
        fechaFinalDatePicker.datePickerMode = .date
        
        fechaInicio.inputView = fechaInicioDatePicker
        fechaFinal.inputView = fechaFinalDatePicker
        
        fechaInicio.inputAccessoryView = createToolBarDateInicio()
        fechaFinal.inputAccessoryView = createToolBarDateFinal()
    }
    
    @objc func donePressedPickerInicio(){
        let row = self.horaInicioPickerView.selectedRow(inComponent: 0)
        self.horaInicioPickerView.selectRow(row, inComponent: 0, animated: false)
        
        self.horaInicio.text = self.horas1[row]
        
        self.view.endEditing(true)
    }
    
    @objc func donePressedPickerFinal(){
        let row = self.horaFinalPickerView.selectedRow(inComponent: 0)
        self.horaFinalPickerView.selectRow(row, inComponent: 0, animated: false)
        
        self.horaFinal.text = self.horas2[row]
        
        self.view.endEditing(true)
    }
    
    @objc func donePressedDateInicio(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        self.fechaInicio.text = dateFormatter.string(from: fechaInicioDatePicker.date)
        
        self.view.endEditing(true)
    }
    
    @objc func donePressedDateFinal(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        self.fechaFinal.text = dateFormatter.string(from: fechaFinalDatePicker.date)
        
        self.view.endEditing(true)
    }
    
    
    @objc private func hideKeyboard(){
        self.view.endEditing(true)
    }

    
}

