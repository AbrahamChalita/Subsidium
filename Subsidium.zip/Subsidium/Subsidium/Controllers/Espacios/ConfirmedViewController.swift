//
//  ConfirmedViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 02/10/22.
//

import UIKit
import Lottie

class ConfirmedViewController: UIViewController {
    
    @IBOutlet weak var confirmedView: UIView!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var animationView: AnimationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpAnimation()
        
        confirmedView.layer.cornerRadius = 6
        confirmedView.layer.masksToBounds = true
        
        cancelButton.layer.cornerRadius = 6
        cancelButton.layer.borderWidth = 1
        cancelButton.layer.borderColor = UIColor.gray.cgColor
    
        // Do any additional setup after loading the view.
    }
    
    @IBAction func cancelAction(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func okAction(_ sender: UIButton) {
        // Aqui se envian los datos
        dismiss(animated: true, completion: nil)
        
    }
    
    func setUpAnimation(){
        let subAnimationView = AnimationView(name: "processingAnimation")
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .playOnce
        animationView.animationSpeed = 1.0
        animationView.addSubview(subAnimationView)
        subAnimationView.frame = animationView.bounds
        subAnimationView.play()
    }
    

}
