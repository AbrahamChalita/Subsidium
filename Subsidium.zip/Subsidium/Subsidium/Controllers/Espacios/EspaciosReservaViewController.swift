//
//  EspaciosReservaViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 29/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore
import Combine
import FSCalendar

struct ResTimes{
    var resDate: String
    var resHour: String
    var resDuration: Int?
};

class EspaciosReservaViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate{
    
    var horas = ["07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00"]
    let noSeMueve = ["07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00"]
    let duracionesNoSeMueve = ["30", "60", "90", "120"]
    var duraciones = ["30", "60", "90", "120"]
    
    let defaults = UserDefaults.standard
    var user: [User] = []
    var formatter = DateFormatter()
    var formatterHours = DateFormatter()
    
    let pickerDuracion = UIPickerView()
    @IBOutlet weak var duracionTexto: UITextField!
    var selectedDuracion: String = ""
    
    let pickerHoras = UIPickerView()
    @IBOutlet weak var horasTexto: UITextField!
    @IBOutlet weak var calendario: FSCalendar!
    var selected: String = ""
    
    @IBOutlet weak var spaceName: UILabel!
    @IBOutlet weak var spaceCapacity: UILabel!
    @IBOutlet weak var spaceDisp: UIImageView!
    @IBOutlet weak var spaceLocation: UILabel!
    @IBOutlet weak var spaceCaracteristics: UIImageView!
    @IBOutlet weak var spaceImage: UIImageView!
    
    //@IBOutlet weak var datePicker: UIDatePicker!
    //@IBOutlet weak var pickerView: UIPickerView!
    
    var hoursFromQuery: [ResTimes] = []
    
    var nombre = ""
    var piso = ""
    var capacidad = ""
    var disponibilidad = UIImage()
    var imagenCaracteristicas = UIImage()
    //var imagenSpace = UIImageV
    var roomId = ""
    var currentRoom = Room(name: "", building: "", proyector: false, wifi: false, board: false, air_conditioner: false, ethernet: false, computers: false, double_monitor: false, seats: 0, energy_outlets: 0, description: "")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        calendario.register(FSCalendarCell.self, forCellReuseIdentifier: "CELL_ROOM")
        calendario.scrollDirection = .horizontal
        calendario.appearance.todayColor = .systemGreen
        
        calendario.dataSource = self
        calendario.delegate = self

        spaceName.text = nombre
        spaceCapacity.text = capacidad
        spaceDisp.image = disponibilidad
        spaceLocation.text = piso
        spaceCaracteristics.image = imagenCaracteristicas
        
        hoursFromQuery = getRoomOccupiedDates()
        
        let urlString = getImageURL(espacio: currentRoom)
        spaceImage.downloaded(from: urlString)
        
        listUsers()
        createPickerDuraciones()
        
    }
    
    func updateUI(with usuarios: [User]){
        DispatchQueue.main.async {
            self.user = self.user
        }
    }
    
    func listUsers() {
        let todo = User.keys
        let predicate = todo.username == defaults.string(forKey: "CurrentUser")
    
        let request = GraphQLRequest<User>.list(User.self, where: predicate)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let todos):
                    print("Successfully retrieved list of Users: \(todos)")
                    self.user = todos
                    self.updateUI(with: todos)
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    
    func getRoomOccupiedDates() -> ([ResTimes]){
        var values: [ResTimes] = []
        let semaphore = DispatchSemaphore(value: 0)
        let todo = Reservation.keys
        let predicate = todo.roomID == currentRoom.id
        let request = GraphQLRequest<Reservation>.list(Reservation.self, where: predicate)
        Amplify.API.query(request: request) { event in
                switch event {
                case .success(let result):
                    switch result {
                    case .success(let todos):
                        print("Successfully retrieved list of Reservations: \(todos)")
                        for i in todos{
                            let val = ResTimes(resDate: i.reservationDate, resHour: i.reservationTime ?? "00:00", resDuration: i.reservationDuration)
                            values.append(val)
                        }
                        semaphore.signal()
                    case .failure(let error):
                        print("Got failed result with \(error.errorDescription)")
                    }
                case .failure(let error):
                    print("Got failed event with error \(error)")
                }
            }
        
        semaphore.wait()
        return values
        
    }
    
    
    func getImageURL(espacio: Room) -> URL{
        var link = URL(string: "google.com")
        let semaphore = DispatchSemaphore(value: 0)
        
        Amplify.Storage.getURL(key: espacio.images[0]!) { event in
            switch event {
            case let .success(url):
                print("Completed, retrieved url correctly")
                link = url
                semaphore.signal()
            case let .failure(storageError):
                print("Failed: \(storageError.errorDescription). \(storageError.recoverySuggestion)")
            }
        }
        
        semaphore.wait()
        
        return link!
    }
  
    
    @IBAction func continueButton(_ sender: UIButton) {
        
        print("Date selected - > \(selected) with timing -----> \(String(describing: horasTexto.text))")
        
        var duracionFinal: Int = 0
        
        if duracionTexto.text == "30"{
            duracionFinal = 30
        }else if duracionTexto.text == "60"{
            duracionFinal = 60
        }else if duracionTexto.text == "90"{
            duracionFinal = 90
        }else if duracionTexto.text == "120"{
            duracionFinal = 120
        }
        
        print("Duration selected ----> \(duracionFinal)")
        
        if !user.isEmpty{
            let userId = user[0].id
            createReservationDB(userID: userId, roomID: roomId, resDate: selected, resTime: horasTexto.text!, state: "Pendiente", resDuration: duracionFinal)
            
        }
         
         
    }
    
    func createReservationDB(userID: String, roomID: String, resDate: String, resTime: String, state: String, resDuration: Int){
        let reservationToCreate = Reservation(userID: userID, roomID: roomID, reservationDate: resDate, reservationTime: resTime, reservationDuration: resDuration, state: state)
        Amplify.API.mutate(request: .create(reservationToCreate)) { event in
            switch event {
            case .success(let result):
                switch result{
                case .success(let res):
                    print("Successfully added reservation to database: \(res)")
                case .failure(let error):
                    print("Got failed result with: \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
        
    }
    


}


extension EspaciosReservaViewController: FSCalendarDelegate, FSCalendarDataSource, FSCalendarDelegateAppearance {
    
    func minimumDate(for calendar: FSCalendar) -> Date {
        return Date()
    }
    
    func maximumDate(for calendar: FSCalendar) -> Date {
        return Calendar.current.date(byAdding: .month, value: 3, to: Date())!
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        formatter.dateFormat = "yyyy-MM-dd"
        self.selected = formatter.string(from: date)
        createPicker(input: formatter.string(from: date))
    }
    
    
    func createPicker(input: String){
        
        formatter.dateFormat = "yyyy-MM-dd"
        formatterHours.dateFormat = "HH:mm"
        
        horas = noSeMueve
        var temp = noSeMueve
        
        for i in hoursFromQuery{
            if input == i.resDate{
                //temp = temp.filter(){$0 != i.resHour}
                print(i.resHour)
                
                //var tempAdded: [String] = []
                var len: Int = 0
                
                if i.resDuration == 30{
                    len = 1
                }else if i.resDuration == 60{
                    len = 2
                }else if i.resDuration == 90{
                    len = 3
                }else if i.resDuration == 120{
                    len = 4
                }
                
                let current = formatterHours.date(from: i.resHour)
                var new = current
                
                for _ in 1...len{
                    new = Calendar.current.date(byAdding: .minute, value: 30, to: new!)
                    let generated = formatterHours.string(from: new!)
                    print(generated)
                    temp = temp.filter(){$0 != generated}
                }
                
                
            }
        }
        
        self.horas = temp
        
        
        pickerHoras.delegate = self
        pickerHoras.dataSource = self
        
        horasTexto.inputView = pickerHoras
        horasTexto.inputAccessoryView = createToolBarPicker()
    }
    
    
    func createPickerDuraciones(){
        pickerDuracion.delegate = self
        pickerDuracion.dataSource = self
        
        duracionTexto.inputView = pickerDuracion
        duracionTexto.inputAccessoryView = createToolBarDuraciones()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if horasTexto.isEditing{
            return horas.count
        }else{
            return duraciones.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if horasTexto.isEditing{
            return horas[row]
        }else{
            return duraciones[row]
        }
        
        
        //return horas[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == pickerHoras{
            self.horasTexto.text = self.horas[row]
            updateDuraciones(input: self.horas[row])
        }else{
            self.duracionTexto.text = self.duraciones[row]
        }
        
        //createPickerDuraciones(input: self.horas[row])
    }
    
    func updateDuraciones(input: String){
        
        print("Raw input -----> \(input)")
        formatterHours.dateFormat = "HH:mm"
        let current = formatterHours.date(from: input)
        
        let forprint = formatterHours.string(from: current!)
        print("Current -----> \(forprint)")
        
        var counter = 0
        var new = current
        
        for i in 1...4{
            new = Calendar.current.date(byAdding: .minute, value: 30, to: new!)
            let generated = formatterHours.string(from: new!)
            
            print("Generated ---> \(generated) in round \(i)")
            
            if horas.contains(generated){
                print("True, horas contains --------> \(generated)")
                counter += 1
            }else{
                break
            }
            
        }
        
        
        if counter == 0{
            self.duraciones = ["0"]
        }else if counter == 1{
            self.duraciones = ["30"]
        }else if counter == 2{
            self.duraciones = ["30", "60"]
        }else if counter == 3{
            self.duraciones = ["30", "60", "90"]
        }else if counter == 4{
            self.duraciones = ["30", "60", "90", "120"]
        }
        
        //self.duraciones = ["Funciona?"]
    }
    
    func createToolBarPicker() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPicker))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    func createToolBarDuraciones() -> UIToolbar{
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressedPickerDuraciones))
        toolbar.setItems([doneButton], animated: true)
        
        return toolbar
    }
    
    @objc func donePressedPicker(){
        let row = self.pickerHoras.selectedRow(inComponent: 0)
        self.pickerHoras.selectRow(row, inComponent: 0, animated: false)
        self.horasTexto.text = self.horas[row]
        
        self.view.endEditing(true)
      
    }
    
    @objc func donePressedPickerDuraciones(){
        let row = self.pickerDuracion.selectedRow(inComponent: 0)
        self.pickerDuracion.selectRow(row, inComponent: 0, animated: false)
        self.duracionTexto.text = self.duraciones[row]
        
        self.view.endEditing(true)
      
    }
    
    func showAlert(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {action in print("Dismiss")}))
        self.present(alert, animated:true, completion: nil)
    }
    
}
