//
//  EspacioTableViewCell.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class EspacioTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nombreEspacio: UILabel!
    @IBOutlet weak var pisoEspacio: UILabel!
    @IBOutlet weak var capacidadEspacio: UILabel!
    @IBOutlet weak var disponibilidadEspacio: UIImageView!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setEspacio(espacio: Room){
        let title: String = espacio.building + " " + espacio.name
        nombreEspacio.text = title
        pisoEspacio.text = espacio.floor ?? "Piso X"
        capacidadEspacio.text = String(espacio.seats)
        disponibilidadEspacio.image = UIImage(named: "green")
    }
    

}

