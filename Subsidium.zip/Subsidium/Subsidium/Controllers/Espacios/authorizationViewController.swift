//
//  authorizationViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 02/10/22.
//

import UIKit
import Lottie

class authorizationViewController: UIViewController {
    
    
    @IBOutlet weak var authorizationView: UIView!
    @IBOutlet weak var cancelButton: UIView!
    @IBOutlet weak var animationView: AnimationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpAnimation()
        
        authorizationView.layer.cornerRadius = 6
        authorizationView.layer.masksToBounds = true
        
        cancelButton.layer.cornerRadius = 6
        cancelButton.layer.borderWidth = 1
        cancelButton.layer.borderColor = UIColor.gray.cgColor
    }
    
    @IBAction func cancelAction(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func okAction(_ sender: UIButton) {
        // Aqui se envian los datos
        dismiss(animated: true, completion: nil)
    }
    
    func setUpAnimation(){
        let subAnimationView = AnimationView(name: "attention")
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .playOnce
        animationView.animationSpeed = 1.0
        animationView.addSubview(subAnimationView)
        subAnimationView.frame = animationView.bounds
        subAnimationView.play()
    }
    
    
}
