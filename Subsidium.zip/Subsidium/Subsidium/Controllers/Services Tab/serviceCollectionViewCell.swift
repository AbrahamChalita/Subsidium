//
//  serviceCollectionViewCell.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import Foundation
import UIKit

class serviceCollectionViewCell: UICollectionViewCell{
    
    @IBOutlet weak var featuredImageView: UIImageView!
    @IBOutlet weak var backgroundColorView: UIView!
    @IBOutlet weak var serviceTitleLabel: UILabel!
    
    
    func setService(servicio: service){
        featuredImageView.image = servicio.featuredImage
        backgroundColorView.backgroundColor = servicio.color
        serviceTitleLabel.text = servicio.title
    }
    
    
}
