//
//  HardwareViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class HardwareViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    

    @IBOutlet weak var tableView: UITableView!
    var devices: [Device] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        fetchHardware()
    }
    
    func fetchHardware(){
        let hardware = Device.keys
        let predicate = hardware.active == true
        let request = GraphQLRequest<Device>.list(Device.self, where: predicate)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                switch result {
                case .success(let lista):
                    print("Successfully retrieved list of Devices: \(lista)")
                    self.devices = lista
                    self.updateUI(with: lista)
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
    }
    
    
    func updateUI(with devices: [Device]){
        DispatchQueue.main.async {
            self.devices = self.devices
            self.tableView.reloadData()
        }
    }

}

extension HardwareViewController {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return devices.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let hardware = devices[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "hardwareCell") as! HardwareTableViewCell
        
        cell.setHardware(hardware: hardware)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CalendarTestViewController") as? CalendarTestViewController
        vc?.currentDevice = devices[indexPath.row]
        
        // HardwareReservationViewController
        
        vc?.modalPresentationStyle = .popover
        self.present(vc!, animated: true)
        
    }
}

/*
 
 let myTabBar = self.storyboard?.instantiateViewController(withIdentifier: "MainTabBarController") as! UITabBarController
 myTabBar.modalPresentationStyle = .fullScreen
 self.present(myTabBar, animated: true)
 */
