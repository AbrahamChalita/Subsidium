//
//  ServicesViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import UIKit

class ServicesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var servicios = service.createArray()
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        

        // Do any additional setup after loading the view.
    }


}

extension ServicesViewController{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return servicios.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let service = servicios[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "serviceCell", for: indexPath) as! serviceCollectionViewCell
        
        cell.setService(servicio: service)
        
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let vc1 = storyboard?.instantiateViewController(withIdentifier: "EspaciosViewController") as? EspaciosViewController
        
        let vc2 = storyboard?.instantiateViewController(withIdentifier: "HardwareViewController") as? HardwareViewController
        
        let vc3 = storyboard?.instantiateViewController(withIdentifier: "LicenciasViewController") as? LicenciasViewController
        
        let choice = servicios[indexPath.row].title
        
        if(choice == "Espacios"){
            self.navigationController?.pushViewController(vc1!, animated: true)
        }else if(choice == "Hardware"){
            self.navigationController?.pushViewController(vc2!, animated: true)
        }else if(choice == "Software"){
            self.navigationController?.pushViewController(vc3!, animated: true)
        }
    }
}

