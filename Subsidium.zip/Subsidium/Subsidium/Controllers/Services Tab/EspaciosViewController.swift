//
//  EspaciosViewController.swift
//  Subsidium
//
//  Created by Abraham Chalita on 28/09/22.
//

import UIKit
import Amplify
import AWSPluginsCore

class EspaciosViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var TableView: UITableView!
    var espacios: [Room] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        TableView.delegate = self
        TableView.dataSource = self
        
        fetchDataEspacios()
    }
    
    func fetchDataEspacios(){
        let space = Room.keys
        let predicate = space.active == true
        let request = GraphQLRequest<Room>.list(Room.self, where: predicate)
        Amplify.API.query(request: request) { event in
            switch event {
            case .success(let result):
                print(result)
                switch result {
                case .success(let lista):
                    print("Successfully retrieved list of Espacios: \(lista)")
                    self.espacios = lista
                    self.updateUI(with: lista)
                case .failure(let error):
                    print("Got failed result with \(error.errorDescription)")
                }
            case .failure(let error):
                print("Got failed event with error \(error)")
            }
        }
        
    }
    
    
    
    func updateUI(with espacios: [Room]){
        DispatchQueue.main.async {
            self.espacios = self.espacios
            self.TableView.reloadData()
        }
    }
    
    
}


extension EspaciosViewController{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return espacios.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let espacio = espacios[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "espacioCell") as! EspacioTableViewCell
        
        cell.setEspacio(espacio: espacio)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "EspaciosReservaViewController") as? EspaciosReservaViewController
        
        vc?.nombre = espacios[indexPath.row].building + " " + espacios[indexPath.row].name
        vc?.roomId = espacios[indexPath.row].id
        vc?.piso = espacios[indexPath.row].floor ?? "1"
        vc?.capacidad = String(espacios[indexPath.row].seats)
        vc?.disponibilidad = UIImage(named: "green")!
        vc?.imagenCaracteristicas = UIImage(named: "caracteristics1")!
        //vc?.imagenSpace = UIImage(named: "espacio")!
        vc?.currentRoom = espacios[indexPath.row]
        
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
}
